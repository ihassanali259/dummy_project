package com.bitsTech.app.ads

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.bitsTech.solutions.app.antithefttracker.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date


class AppOpenManager(private var myApplication: Application) : LifecycleObserver, Application.ActivityLifecycleCallbacks {
    companion object {
        private const val LOG_TAG = "AppOpenManager"
        var adCounter = 0
        var appOpenAd: AppOpenAd? = null
    }
    private lateinit var loadCallback: AppOpenAd.AppOpenAdLoadCallback
    private var currentActivity: Activity? = null
    private var isShowingAd: Boolean = false
    private var loadTime: Long = 0

    init {
        this.myApplication.registerActivityLifecycleCallbacks(this)
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }
    @OnLifecycleEvent(Lifecycle.Event.ON_RESUME)
    fun onResume() {
        Log.d(LOG_TAG, "onResume")
        showAdIfAvailable()
    }
    private fun showAdIfAvailable() {
        if (isAdAvailable()) {
            if (!AppInterstitialAds.isInterstitialAdsShowing) {
                Log.d(LOG_TAG, "Will show ad.")
                val fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        appOpenAd = null
                        isShowingAd = false
                        fetchAd()
                        Log.d(LOG_TAG, "Ad dismissed.")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        Log.d(LOG_TAG, "Ad impression.")
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                        Log.d(LOG_TAG, "Ad failed to show: ${adError.message}")
                    }

                    override fun onAdShowedFullScreenContent() {
                        isShowingAd = true
                        Log.d(LOG_TAG, "Ad showed.")
                    }
                }
                appOpenAd?.fullScreenContentCallback = fullScreenContentCallback
                currentActivity?.let {
                    appOpenAd?.show(it)
                } ?: Log.d(LOG_TAG, "Current activity is null.")
            }
        } else {
            Log.d(LOG_TAG, "Cannot show ad. Ad is not available.")
            fetchAd()
        }
    }

    fun fetchAd() {
        if (isAdAvailable()) {
            return
        }
        loadCallback = object : AppOpenAd.AppOpenAdLoadCallback() {
            override fun onAdFailedToLoad(p0: LoadAdError) {
                super.onAdFailedToLoad(p0)
                Log.d(LOG_TAG, "onAdFailedToLoad: ${p0.code}")
            }

            override fun onAdLoaded(p0: AppOpenAd) {
                super.onAdLoaded(p0)
                appOpenAd = p0
                this@AppOpenManager.loadTime = (Date()).time
                Log.d(LOG_TAG, "Ad loaded.")
            }
        }
        val request: AdRequest = getAdRequest()
        AppOpenAd.load(
            myApplication,
            myApplication.applicationContext.getString(R.string.AM_APP_OPEN),
            request,
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            loadCallback
        )
    }

    private fun getAdRequest(): AdRequest {
        return AdRequest.Builder().build()
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = (Date()).time - this.loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return (dateDifference < (numMilliSecondsPerHour * numHours))
    }

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
        Log.d(LOG_TAG, "Activity started: ${activity.localClassName}")
    }

    override fun onActivityDestroyed(activity: Activity) {
        currentActivity = null
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
        Log.d(LOG_TAG, "Activity resumed: ${activity.localClassName}")
    }
}
