package com.bitsTech.app.antithefttracker.flashLight

import android.app.ActivityManager
import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import kotlin.concurrent.thread

class FlashingLightManager(context: Context) {
    private val cameraManager: CameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    // Check if the cameraIdList is empty before accessing it
    private val cameraId: String? = cameraManager.cameraIdList.firstOrNull()

    @Volatile
    private var isBlinking: Boolean = false

    init {
        if (cameraId == null) {
            throw IllegalStateException("No camera available on this device.")
        }
    }

    fun startBlink() {
        val id = cameraId ?: return // Exit if no camera ID is available
        if (!isBlinking) {
            isBlinking = true
            try {
                cameraManager.setTorchMode(id, true)
                thread(start = true) {
                    var isOn = true
                    while (isBlinking) {
                        try {
                            cameraManager.setTorchMode(id, isOn)
                            isOn = !isOn
                            Thread.sleep(500) // Handle possible interruptions
                        } catch (e: CameraAccessException) {
                            // Handle any errors related to accessing the camera
                            e.printStackTrace()
                            break
                        } catch (e: InterruptedException) {
                            // Handle interruptions during sleep
                            e.printStackTrace()
                            break
                        }
                    }
                    // Ensure the torch is turned off when blinking stops or on error
                    try {
                        cameraManager.setTorchMode(id, false)
                    } catch (e: CameraAccessException) {
                        e.printStackTrace()
                    }
                }
            } catch (e: CameraAccessException) {
                // Handle errors when setting the initial torch mode
                e.printStackTrace()
                // Ensure the isBlinking flag is reset
                isBlinking = false
            }
        }
    }

    fun stopBlinking() {
        isBlinking = false
        // Ensure the torch is turned off when stopping blinking
        try {
            cameraId?.let {
                cameraManager.setTorchMode(it, false)
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    fun isServiceRunning(context: Context, serviceClass: Class<*>): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return activityManager.getRunningServices(Int.MAX_VALUE).any { service ->
            serviceClass.name == service.service.className
        }
    }
}
