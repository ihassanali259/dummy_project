package com.bitsTech.app.antithefttracker.ui.activities

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.viewpager2.widget.ViewPager2
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.antithefttracker.adapter.ViewPagerAdapter
import com.bitsTech.app.antithefttracker.model.Slider
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivityHowToUseBinding

class HowToUseActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHowToUseBinding
    private var listItemsDark = mutableListOf<Slider>()
    private var listItemsLight = mutableListOf<Slider>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHowToUseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val adNativeID=if(SplashActivity.isBundleDebug){
            "ca-app-pub-3940256099942544/2247696110"
        }else{
            //real   ca-app-pub-4992414586834585/1016852900
            "ca-app-pub-4992414586834585/1016852900"
        }
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
       // AppNativeAds.loadAndInflateSmallNativeAdMob(this,adNativeID, binding.frameLayoutAds)
        listItemsDark.add(Slider(R.drawable.d1, getString(R.string.txt1)))
        listItemsDark.add(Slider(R.drawable.d2, getString(R.string.txt2)))
        listItemsDark.add(Slider(R.drawable.d3, getString(R.string.txt3)))
        listItemsDark.add(Slider(R.drawable.d4, getString(R.string.txt5)))

        listItemsLight.add(Slider(R.drawable.l1, getString(R.string.txt1)))
        listItemsLight.add(Slider(R.drawable.l2, getString(R.string.txt2)))
        listItemsLight.add(Slider(R.drawable.l3, getString(R.string.txt3)))
        listItemsLight.add(Slider(R.drawable.l4, getString(R.string.txt5)))

        binding.btnFinish.setOnClickListener {
            val currentPosition = binding.viewPager.currentItem
            if(currentPosition < getThemeDependentList().size - 1) {
                binding.viewPager.setCurrentItem(currentPosition + 1, true)
            } else if(currentPosition == getThemeDependentList().size - 1) {
                startActivity( Intent(this, MainActivity::class.java))
                finish()
            }
        }
        val adapter = ViewPagerAdapter(getThemeDependentList())
        binding.viewPager.adapter = adapter
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if(position == getThemeDependentList().size - 1) {
                    binding.btnFinish.text = getString(R.string.finish)
                    binding.btnBack.visibility = View.INVISIBLE
                } else {
                    binding.btnFinish.text = getString(R.string.next)
                    binding.btnBack.visibility = View.VISIBLE
                }
            }
        })
        binding.indicator.attachTo(binding.viewPager)
        binding.btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }
    private fun getThemeDependentList(): List<Slider> {
        return if(isDarkMode()) {
            listItemsDark
        } else {
            listItemsLight
        }
    }
    private fun isDarkMode(): Boolean {
        return resources?.configuration?.uiMode?.and(Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
}