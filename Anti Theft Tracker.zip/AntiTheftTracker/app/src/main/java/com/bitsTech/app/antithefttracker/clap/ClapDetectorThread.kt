package com.bitsTech.app.antithefttracker.clap

import android.media.AudioFormat
import android.util.Log
import com.bitsTech.app.antithefttracker.model.OnWaveDetectedListener
import com.musicg.api.ClapApi
import com.musicg.wave.WaveHeader
import java.util.LinkedList

class ClapDetectorThread(private val recorder: ClapRecorderThread) : Thread() {
    private val waveHeader: WaveHeader
    private var clapApi: ClapApi? = null

    @Volatile
    private var _thread: Thread? = null
    private val clapResult = LinkedList<Boolean>()
    private var numeClaps = 0
    private val whistleCheckLength = 1
    private val whistlePassScore = 1
    private var onSignalsDetectedListener: OnWaveDetectedListener? = null

    init {
        val audioRecord = recorder.audioRecord

        var bitsPerSample = 0
        if (audioRecord.audioFormat == AudioFormat.ENCODING_PCM_16BIT) {
            bitsPerSample = 16
        } else if (audioRecord.audioFormat == AudioFormat.ENCODING_PCM_8BIT) {
            bitsPerSample = 8
        }

        var channel = 0
        // whistle detection only supports mono channel
        if (audioRecord.channelConfiguration == AudioFormat.CHANNEL_IN_MONO) {
            channel = 1
        }

        waveHeader = WaveHeader()
        waveHeader.channels = channel
        waveHeader.bitsPerSample = bitsPerSample
        waveHeader.sampleRate = audioRecord.sampleRate
        clapApi = ClapApi(waveHeader)
    }

    private fun initBuffer() {
        numeClaps = 0
        clapResult.clear()


        // init the first frames
        for (i in 0 until whistleCheckLength) {
            clapResult.add(false)
        }
        // end init the first frames
    }

    override fun start() {
        _thread = Thread(this)
        _thread!!.start()
    }

    fun stopDetection() {
        _thread = null
    }

    override fun run() {
        try {
            var buffer: ByteArray?
            initBuffer()

            val thisThread = currentThread()
            while (_thread === thisThread) {
                // detect sound
                buffer = recorder.frameBytes


                // audio analyst
                if (buffer != null) {
                    // sound detected
                    // whistle detection
                    //System.out.println("*Whistle:");
                    val isClap = clapApi?.isClap(buffer)
                    if (clapResult.first) {
                        numeClaps--
                    }

                    clapResult.removeFirst()
                    clapResult.add(isClap == true)

                    if (isClap == true) {
                        Log.i("IS_CLAP", "run: isclap")
                        numeClaps++
                    }

                    //System.out.println("num:" + numWhistles);
                    if (numeClaps >= whistlePassScore) {
                        // clear buffer
                        initBuffer()
                        onWhistleDetected()
                    }
                    // end whistle detection
                } else {
                    // no sound detected
                    if (clapResult.first) {
                        numeClaps--
                    }
                    clapResult.removeFirst()
                    clapResult.add(false)
                }
                // end audio analyst
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun onWhistleDetected() {
        if (onSignalsDetectedListener != null) {
            onSignalsDetectedListener!!.onWhistleDetected()
        }
    }

    fun setOnSignalsDetectedListener(listener: OnWaveDetectedListener?) {
        onSignalsDetectedListener = listener
    }
}