package com.bitsTech.app.antithefttracker.model

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.app.ActivityCompat
import kotlin.math.abs

@SuppressLint("MissingPermission")
class RecorderThread : Thread() {
    val audioRecord: AudioRecord
    private var isRecording = false
    private val channelConfiguration = AudioFormat.CHANNEL_IN_MONO
    private val audioEncoding = AudioFormat.ENCODING_PCM_16BIT
    private val sampleRate = 44100
    private val frameByteSize = 2048 // for 1024 fft size (16bit sample size)
    var buffer: ByteArray

    init {
        val recBufSize = AudioRecord.getMinBufferSize(
            sampleRate,
            channelConfiguration,
            audioEncoding
        ) // need to be larger than size of a frame

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfiguration,
            audioEncoding,
            recBufSize
        )
        buffer = ByteArray(frameByteSize)
    }

    fun isRecording(): Boolean {
        return this.isAlive && isRecording
    }

    fun startRecording() {
        try {
            audioRecord.startRecording()
            isRecording = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopRecording() {
        try {
            audioRecord.stop()
            audioRecord.release()
            isRecording = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    val frameBytes: ByteArray?
        get() {
            audioRecord.read(buffer, 0, frameByteSize)


            // analyze sound
            var totalAbsValue = 0
            var sample: Short = 0
            var averageAbsValue = 0.0f

            var i = 0
            while (i < frameByteSize) {
                sample = (buffer[i].toInt() or (buffer[i + 1].toInt() shl 8)).toShort()
                totalAbsValue += abs(sample.toInt())
                i += 2
            }
            averageAbsValue = (totalAbsValue / frameByteSize / 2).toFloat()

            //System.out.println(averageAbsValue);

            // no input
            if(averageAbsValue < 30) {
                return null
            }

            return buffer
        }

    override fun run() {
        startRecording()
    }
}