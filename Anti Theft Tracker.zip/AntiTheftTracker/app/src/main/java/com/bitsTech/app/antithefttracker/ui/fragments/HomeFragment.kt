package com.bitsTech.app.antithefttracker.ui.fragments

import android.Manifest
import android.app.ActionBar.LayoutParams
import android.app.Activity
import android.app.Dialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bitsTech.app.ads.AppInterstitialAds
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.device_admin.MydeviceAdminReciever
import com.bitsTech.app.antithefttracker.ui.activities.HowToUseActivity
import com.bitsTech.app.antithefttracker.ui.activities.SplashActivity
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.FragmentHomeBinding
import com.bitsTech.solutions.app.antithefttracker.databinding.PermissionDialogBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder


class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private var isDarkMode = false
    private var cancelClicked = false
    private var hasbeenOpened = false
    private val notificationPermissionRequestCode = 1001
    private val sharedPreferences by lazy {
        requireContext().getSharedPreferences("MyThemePrefs", AppCompatActivity.MODE_PRIVATE)
    }

    private var devicePolicyManager: DevicePolicyManager? = null
    private var adminComponent: ComponentName? = null

    private lateinit var permissionDialogBinding: PermissionDialogBinding
    private var dialog: Dialog? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(layoutInflater)
        permissionDialogBinding = PermissionDialogBinding.inflate(layoutInflater)
        binding.apply {
            // AppBannerAds.loadAMBannerCollapsbile(requireContext(), binding.frameBanner)
            findByClap.setOnClickListener {
                findNavController().navigate(R.id.action_homeFragment_to_clapDetectFragment)
            }
            cardAntiTheft.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_antiPocketDetectFragment)
//                    }
//                }
            }
            cardFullChargeDetect.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_fullChargingDetectionFragment)
//                    }
//                }
            }
            cardWifiDetect.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_wifiDetectionFragment)
//                    }
//                }
            }
            cardMotionDetect.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_motionDetectionFragment)
//                    }
//                }
            }
            btnHowtoUse.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                startActivity(Intent(requireContext(), HowToUseActivity::class.java))
//                    }
//                }
            }
            ChargerRemoval.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_chargerDetection)
//                    }
//                }
            }
            cardHandsFreeDetect.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_handFreeDetect)
//                    }
//                }
            }
            cardwhistle.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_whistleDetection)
//                    }
//                }
            }
            setting.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_homeFragment_to_menuFragment)
//                    }
//                }
            }
            binding.darkMode.setOnClickListener {

                devicePolicyManager =
                    requireContext().getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager?
                adminComponent = ComponentName(requireContext(), MydeviceAdminReciever::class.java)

                if (devicePolicyManager?.isAdminActive(adminComponent!!) == true) {
                    Toast.makeText(requireContext(), "already admin", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                    intent.putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Additional text explaining why we need this permission"
                    )
                    startActivityForResult(intent, 200)
                }


//                CoroutineScope(Dispatchers.Main).launch {
//                    Log.d("is_dark_mode", "btn_clicked.. ")
//                    if(AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES) {
//
//                        sharedPreferences.edit().putBoolean("IS-DARK-MODE", false).apply()
//                        AppCompatDelegate.setDefaultNightMode(MODE_NIGHT_NO)
//                        binding.darkMode.setImageResource(R.drawable.light_mode_icon)
//                    } else {
//                        sharedPreferences.edit().putBoolean("IS-DARK-MODE", true).apply()
//                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
//                        Log.d("is_dark_mode", "else isDarkMode..$isDarkMode ")
//                        binding.darkMode.setImageResource(R.drawable.dark_mode_icon)
//                    }
//                }
            }

        }
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        Log.d("hasbeenOpened", "onResume:hasbeenOpened $hasbeenOpened ")
        if (!permissionOK()) {
            openDialog()
        } else {
            if (!isNotificationPermissionGranted()) {
                showNotificationPermissionDialog()
            }
        }

    }

    private fun isNotificationPermissionGranted(): Boolean {
        val permission = Manifest.permission.POST_NOTIFICATIONS
        val result = ContextCompat.checkSelfPermission(requireContext(), permission)
        return result == PackageManager.PERMISSION_GRANTED
    }

    private fun showNotificationPermissionDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Notification Permission Required")
            .setMessage("Please grant the notification permission to continue.")
            .setPositiveButton("Grant") { _, _ ->
                grantNotificationPermission(requireContext())
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                requireActivity().finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun requestNotificationPermission() {
        AppInterstitialAds.isInterstitialAdsShowing = true
        ActivityCompat.requestPermissions(
            requireActivity(),
            arrayOf(Manifest.permission.POST_NOTIFICATIONS),
            notificationPermissionRequestCode
        )
    }

    private fun grantNotificationPermission(context: Context) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", context.packageName, null))
            ActivityCompat.startActivityForResult(
                context as Activity,
                intent,
                notificationPermissionRequestCode,
                null
            )
        } else {
            requestNotificationPermission()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode == notificationPermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                AppInterstitialAds.isInterstitialAdsShowing = false
            } else {
                showPermissionDeniedDialog()
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
        AppInterstitialAds.isInterstitialAdsShowing = false
    }

    private fun showPermissionDeniedDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Permission Denied")
            .setMessage("You have denied the notification permission. Please grant the permission to continue.")
            .setPositiveButton("Settings") { _, _ ->
                openAppSettings()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                requireActivity().finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.fromParts("package", requireActivity().packageName, null)
        startActivity(intent)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (AppCompatDelegate.getDefaultNightMode() == MODE_NIGHT_NO) {
            binding.darkMode.setImageResource(R.drawable.light_mode_icon)
        } else {
            binding.darkMode.setImageResource(R.drawable.dark_mode_icon)
        }
        val adNativeID = if (SplashActivity.isBundleDebug) {
            "ca-app-pub-3940256099942544/2247696110"
        } else {
            //real   ca-app-pub-4992414586834585/1016852900
            "ca-app-pub-4992414586834585/1834892350"
        }
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
        AppNativeAds.loadAndInflateSmallNativeAdMob(
            requireContext(),
            adNativeID,
            binding.frameLayoutAds
        )


    }

    private fun openDialog() {
        if (!MyApplication.prefs!!.getBoolean("hasbeenOpened", false)) {
            val view = permissionDialogBinding.root
            if (view.parent != null) {
                (view.parent as ViewGroup).removeView(view)
            }
            dialog = Dialog(requireContext(), LayoutParams.MATCH_PARENT)
            dialog!!.setContentView(view)
            dialog!!.window!!.setBackgroundDrawableResource(R.color.blur)
            dialog!!.window!!.setWindowAnimations(R.style.DialogUpToDownAnimation)
            dialog!!.show()
            Log.d("hasbeenOpened", "onResume:hasbeenOpened $hasbeenOpened ")

            permissionDialogBinding.apply {
                permissionDialogBinding.no.setOnClickListener {
                    cancelClicked = true
                    MyApplication.prefs!!.putBoolean("hasbeenOpened", true)
                    Log.d("hasbeenOpened", "dialog NO:hasbeenOpened $hasbeenOpened ")
                    dialog!!.dismiss()
                    if (!isNotificationPermissionGranted()) {
                        showNotificationPermissionDialog()
                    }
                }
                permissionDialogBinding.yes.setOnClickListener {
                    displayOverlayPermission()
                    MyApplication.prefs!!.putBoolean("hasbeenOpened", true)
                    dialog!!.dismiss()
                    Log.d("hasbeenOpened", "dialog Yes:hasbeenOpened $hasbeenOpened ")

                }
            }
        }
    }

    private fun displayOverlayPermission() {
        val REQUEST_CODE = 101
        val myIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        myIntent.data = Uri.parse("package:${requireActivity().packageName}")
        startActivityForResult(myIntent, REQUEST_CODE)

    }

    private fun permissionOK(): Boolean {
        //   AppInterstitialAds.isInterstitialAdsShowing=Settings.canDrawOverlays(requireContext())
        return Settings.canDrawOverlays(requireContext())
    }

}