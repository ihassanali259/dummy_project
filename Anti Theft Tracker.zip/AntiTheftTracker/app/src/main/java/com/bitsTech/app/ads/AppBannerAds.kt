package com.bitsTech.app.ads

import android.content.Context
import android.content.res.Resources
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.bitsTech.solutions.app.antithefttracker.R
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.firebase.Firebase
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.analytics
import com.google.firebase.analytics.logEvent

class AppBannerAds {

    companion object {
        var adRequests = 0
        var isAdmobAdFailedtoLoad = false
        private var adView: AdView? = null

        fun loadAMBanner(context: Context, bannerContainer: FrameLayout) {

            val adView = AdView(context)

            adView.setAdSize(AdSize.BANNER)

            adView.adUnitId = context.getString(R.string.AM_BANNER_AD_ID)

            val adRequest = AdRequest.Builder().build()

            bannerContainer.removeAllViews()
            bannerContainer.addView(adView)



            adView.adListener = object : AdListener() {
                override fun onAdFailedToLoad(p0: LoadAdError) {
                    super.onAdFailedToLoad(p0)

                }

                override fun onAdLoaded() {
                    bannerContainer.visibility = View.VISIBLE
                    super.onAdLoaded()

                }
            }
            adView.loadAd(adRequest)

        }



        fun loadAMBannerCollapsbile(
            context: Context,
            bannerContainer: FrameLayout,
        ) {
            val adView = AdView(context)
            adView.adUnitId = context.getString(R.string.AM_BANNER_COLLAPSIBLE_ID)

//            adView.adUnitId = "ca-app-pub-3940256099942544/2014213617"

            adView.setAdSize(setAdsSize(context, bannerContainer))

            val extras = Bundle()
            extras.putString("collapsible", "bottom")

            adView.adListener = object : AdListener() {
                override fun onAdImpression() {
                    super.onAdImpression()
                    Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}
                }

                override fun onAdFailedToLoad(p0: LoadAdError) {
                    super.onAdFailedToLoad(p0)
                    loadAMBanner(context, bannerContainer)
                }
            }
            val adRequest = AdRequest.Builder()
                .addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
                .build()

            bannerContainer.addView(adView)

            adView.loadAd(adRequest)

        }
        private fun setAdsSize(context: Context, container: ViewGroup?): AdSize {
            val displayMetrics = Resources.getSystem().displayMetrics

            val adWidthPixels = if(container!!.width > 0) {
                container.width.toFloat()
            } else {
                displayMetrics.widthPixels.toFloat()
            }
            val density = displayMetrics.density
            val adWidth = (adWidthPixels / density).toInt()
            return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth)
        }
    }
}