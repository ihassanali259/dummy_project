package com.example.intruderselfie

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat.startForeground
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleService
import com.bitsTech.app.antithefttracker.ui.activities.MainActivity
import com.bitsTech.solutions.app.antithefttracker.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class IntruderService : LifecycleService() {
    private var imageCapture: ImageCapture? = null
    private lateinit var outputDirectory: File


    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int,
    ): Int {
        super.onStartCommand(intent, flags, startId)
        createNotificationChannel()
        outputDirectory = getOutputDirectory()
        startCamera()

        startForeground(1, createNotification())
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val cameraSelector =
                CameraSelector
                    .Builder()
                    .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                    .build()

            imageCapture =
                ImageCapture
                    .Builder()
                    .build()

            try {
                // Bind use cases to the lifecycle owner
                cameraProvider.bindToLifecycle(this as LifecycleOwner, cameraSelector, imageCapture)

                // Capture image when button is clicked
                captureImage()
            } catch (e: Exception) {
                Log.i("device_admin", "startCamera:${e.toString()} ")
                e.printStackTrace()
                stopSelf() // Stop the service if there's an error
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureImage() {
        val photoFile =
            File(
                outputDirectory,
                SimpleDateFormat(
                    "yyyyMMdd_HHmmss",
                    Locale.US,
                ).format(System.currentTimeMillis()) + ".jpg",
            )

        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        imageCapture?.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exception: ImageCaptureException) {
                    Log.e("device_admin", "Photo capture failed: ${exception.message}", exception)
                    exception.printStackTrace()
                    stopSelf() // Stop the service on error
                }

                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    Log.d("device_admin", "Photo capture succeeded: ${photoFile.absolutePath}")
                    // Process the saved image file as needed
                    stopSelf()
                }
            },
        )
    }

    private fun getOutputDirectory(): File {
        val mediaDir =
            File(
                Environment.DIRECTORY_DCIM,
                resources.getString(R.string.app_name),
            ).apply { mkdirs() }
        return if (mediaDir.exists()) mediaDir else filesDir
    }

    override fun onDestroy() {
        super.onDestroy()
        imageCapture = null

    }

    private fun createNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent =
            PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_IMMUTABLE,
            )

        return NotificationCompat
            .Builder(this, "CHANNEL_ID")
            .setContentTitle("Anti-theft Alarm")
            .setContentText("Monitoring lockscreen attempts")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel =
                NotificationChannel(
                    "CHANNEL_ID",
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT,
                )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(serviceChannel)
        }
    }

    companion object {
        fun captureImageOnPasswordFailed() {

        }
    }
}
