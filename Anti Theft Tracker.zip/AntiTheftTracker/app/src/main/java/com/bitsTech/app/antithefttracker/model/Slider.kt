package com.bitsTech.app.antithefttracker.model

data class Slider(val img:Int,val disp:String) {
}