package com.bitsTech.app.antithefttracker.intrface

interface UpdateUIListener {
    companion object {
        var listener: Listener? = null
        fun updateData(isServiceRunning: Boolean?) {
            listener?.getData(isServiceRunning ?: false)
        }
    }

    interface Listener {
        fun getData(isServiceRunning: Boolean)
    }
}