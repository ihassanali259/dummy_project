package com.example.intruderselfie

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserHandle
import android.util.Log

class DeviceAdminSample : DeviceAdminReceiver() {
    override fun onEnabled(
        context: Context,
        intent: Intent,
    ) {
        Log.i("device_admin", "is now admin")
    }

    override fun onPasswordFailed(
        context: Context,
        intent: Intent,
        user: UserHandle,
    ) {
        super.onPasswordFailed(context, intent, user)
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.TIRAMISU) {
            context.startService(Intent(context, IntruderService::class.java))
        } else
            context.startService(Intent(context, IntruderService::class.java))
    }
}
