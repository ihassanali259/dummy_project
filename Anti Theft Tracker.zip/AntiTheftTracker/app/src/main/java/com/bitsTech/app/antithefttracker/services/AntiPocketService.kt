package com.bitsTech.app.antithefttracker.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.TextView
import androidx.annotation.RequiresApi
import com.bitsTech.solutions.app.antithefttracker.R

import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import com.airbnb.lottie.LottieAnimationView
import com.airbnb.lottie.LottieDrawable
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.flashLight.FlashingLightManager
import com.bitsTech.app.antithefttracker.intrface.UpdateUIListener
import com.bitsTech.app.antithefttracker.ui.activities.LockScreenActivity
import com.bitsTech.app.antithefttracker.ui.activities.MainActivity
import com.bitsTech.app.antithefttracker.ui.activities.WindowActivity
import com.bitsTech.app.antithefttracker.vibration.VibrationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class AntiPocketService : Service(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private var isActivityStarted = false
    private var isSensorSleep = false
    private var sleepCount = 0
    private var isVibrate=false
    private var isFlash=false
    private var radioOnce=false
    private var radioAlways = false
    private var mediaPlayer: MediaPlayer? = null
    private var isProximitySensorEnabled = false
    private lateinit var lastSelected: String
    private lateinit var flashlightManager: FlashingLightManager
    private lateinit var vibrationManager: VibrationManager
    private var isDetected=false

    private var overlayView: View? = null

    companion object {
        var isServiceRunning = false
        var isTonePlaying = false
        val channelId = "my_channel_id"
        var isOverlayWindowStart=false
    }

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        CoroutineScope(Dispatchers.Main).launch {
            UpdateUIListener.updateData(true)
        }
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        lastSelected =
            MyApplication.prefs!!.getString("selected_tone", R.raw.alert1.toString()).toString()
        isFlash=MyApplication.prefs!!.getBoolean("ANTITHEFT_FLASH",false)
        isVibrate=MyApplication.prefs!!.getBoolean("ANTITHEFT_VIBRATE",false)
        radioAlways = MyApplication.prefs!!.getBoolean("isRadioAlways", false)
        radioOnce = MyApplication.prefs!!.getBoolean("isRadioOnce", false)
        mediaPlayer = MediaPlayer.create(this, lastSelected.toInt())
        flashlightManager = FlashingLightManager(this)
        vibrationManager = VibrationManager(this)
    }
    @RequiresApi(Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startDetection()
        val notification=createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ServiceCompat.startForeground(this, 101,
                notification, FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(101, notification)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }
    override fun onDestroy() {
        super.onDestroy()
        stopDetection()
        mediaPlayer!!.stop()
        vibrationManager.stopVibrate()
        flashlightManager.stopBlinking()
        isActivityStarted = false
        isServiceRunning = false
        sleepCount=0
        isSensorSleep=false
        UpdateUIListener.updateData(false)
    }
    private fun startDetection() {
        sensorManager.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL)
    }
    private fun stopDetection() {
        sensorManager.unregisterListener(this)
    }
    private fun startAction() {
        val lockIntent = Intent(applicationContext, LockScreenActivity::class.java)
        lockIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        lockIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(lockIntent)
    }
    private fun createNotification(): Notification {
        val intent = Intent(this, WindowActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AntiTheft Alarm")
            .setContentText("tap to stop")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setTicker("Anti Theft")
            .build()
    }
    private fun createNotificationChannel() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Anti Theft Alarm",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = "AntiPocket Detection service"
            channel.lightColor = Color.BLUE
            channel.lockscreenVisibility = NotificationCompat.VISIBILITY_PRIVATE

            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    @RequiresApi(Build.VERSION_CODES.O)
      override fun onSensorChanged(event: SensorEvent?) {
        val value = event!!.values[0]
        Log.d("Proximity_event_values", "values-> ${value} ")
          if(event.sensor.type==Sensor.TYPE_PROXIMITY){
              if(value<=-0.0f){
                  isSensorSleep = true
                  sleepCount = 1
                  Log.d("Proximity_event_values", "Device is in Pocket  $value")
              }else{
                  Log.d("Proximity_event_values", "Device away from Pocket ")
              }
              if(!isActivityStarted) {
                  isDetected=true
                  if(sleepCount == 1 && value >= 1f) {
                      isSensorSleep = false
                      isProximitySensorEnabled = true
                      isTonePlaying = true
                      Handler(Looper.getMainLooper()).postDelayed({
                         // showOverlayWindow()
                          //addOverlayWindow()
                          startAction()
                          Log.d("Proximity_event_values", "Device away from Pocket $value ")
                          mediaPlayer = MediaPlayer.create(this, lastSelected.toInt())
                          mediaPlayer!!.isLooping = radioAlways
                          mediaPlayer!!.start()
                          sleepCount = 0
                      }, 500)

                      if(isVibrate) {
                          vibrationManager.startVibrate(700)
                      }
                      if(isFlash) {
                          flashlightManager.startBlink()
                      }
                      isProximitySensorEnabled = false
                  }
              }
          }
      }
}
