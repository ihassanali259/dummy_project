package com.bitsTech.app.antithefttracker.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.akexorcist.localizationactivity.ui.LocalizationActivity
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.intrface.OnItemClickListener
import com.bitsTech.app.antithefttracker.model.Language
import com.bitsTech.app.antithefttracker.model.Languages
import com.bitsTech.app.antithefttracker.model.OnBoargingAdapter
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivityChangeLangugeBinding
import java.util.Locale

class OnBoardingActivity : LocalizationActivity(), OnItemClickListener {
    private lateinit var binding: ActivityChangeLangugeBinding
    private val items = mutableListOf(
        Languages(R.drawable.english_flag_icon, "System Language", "en"),
        Languages(R.drawable.arabic_flag, "Arabic", "ar"),
        Languages(R.drawable.bangladesh_flag, "Bangali", "bn"),
        Languages(R.drawable.czech_flag, "Czechia", "cs"),
        Languages(R.drawable.hindi_flag, "Hindi", "hi"),
        Languages(R.drawable.portuguese_flag, "Portugese", "pt"),
        Languages(R.drawable.spanish_flag, "Spanish", "es"),
        Languages(R.drawable.turkey_flag, "Turkish", "tr"),
        Languages(R.drawable.german_flag, "German", "de"),
        Languages(R.drawable.persian_flag, "Persian ", "fa"),
        Languages(R.drawable.korea_flag, "Korean ", "ko"),
        Languages(R.drawable.ukrainian_flag, "Ukrainian ", "uk"),
        Languages(R.drawable.vietnamese_flag, "Vietnamese ", "vi")
    )

    private lateinit var adapter: OnBoargingAdapter
    private var selectedItemPosition: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangeLangugeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MyApplication.prefs!!.putBoolean("IS_OPENED", true)
        val adNativeID=if(SplashActivity.isBundleDebug){
            "ca-app-pub-3940256099942544/2247696110"
        }else{
            //real    ca-app-pub-4992414586834585/1129120277
            "ca-app-pub-4992414586834585/1129120277"
        }
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
         AppNativeAds.loadAndInflateSmallNativeAdMob(this,adNativeID, binding.Ad)
        val savedLanguageCode = MyApplication.prefs!!.getString("selected_language", "en")
        val savedLanguagePosition = items.indexOfFirst { it.languageCode == savedLanguageCode }
        selectedItemPosition = if(savedLanguagePosition != -1) savedLanguagePosition else 0
        binding.Apply.setOnClickListener {
            val selectedLanguageCode = items[selectedItemPosition].languageCode
            val languageName=items[selectedItemPosition].text
            MyApplication.prefs?.putString("languageName",languageName)
            Log.d("selected_language", "on click done-->$selectedLanguageCode ")
            if(MyApplication.prefs!!.getBoolean("WelcomeScreenOpened", true)) {
                Log.d("language_checked", "Main activity is not opened ")
                setLanguage(selectedLanguageCode)
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            } else {
                if(selectedLanguageCode == "en") {
                    setLanguage(selectedLanguageCode)
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                else {
                    setLanguage(selectedLanguageCode)
                    Log.d("language_checked", "Main activity already opened ")
                    // Recreate the current activity to apply the language change
                    recreate()
                    startActivity(Intent(this, SplashActivity::class.java))
                    finish()
                }
            }
        }
        binding.recycleView.layoutManager = LinearLayoutManager(this)
        adapter = OnBoargingAdapter(
            items,
            this@OnBoardingActivity,
            selectedItemPosition
        ) // Pass selectedItemPosition
        binding.recycleView.adapter = adapter

    }


    private fun applyLanguage(language: Language) {
        val locale = when (language.name) {
            "System Language" -> Locale("en")
            "Arabic" -> Locale("ar")
            "Bangali" -> Locale("bn")
            "Chinese" -> Locale("zh")
            "Czech" -> Locale("cs")
            "Hindi" -> Locale("hi")
            "German" -> Locale("de")
            "Japnese" -> Locale("ja")
            "Korean" -> Locale("ko")
            "Persian" -> Locale("fa")
            "Portugese" -> Locale("pt")
            "Turkish" -> Locale("tr")
            "Ukrainian" -> Locale("uk")
            "Vietnamese" -> Locale("vi")
            "Spanish" -> Locale("es")
            else -> Locale("en") // Default to English
        }

        setLanguage(locale)

    }
    override fun onBackPressed() {
     //   finish() // Finish the current activity
    }

    override fun onItemClick(position: Int) {
        if(position != selectedItemPosition) {
            val previousSelectedItemPosition = selectedItemPosition
            selectedItemPosition = position
            adapter.setSelectedItemPosition(selectedItemPosition)
            adapter.notifyItemChanged(previousSelectedItemPosition)
            adapter.notifyItemChanged(selectedItemPosition)
            val selectedLanguageCode = items[selectedItemPosition].languageCode
            MyApplication.prefs!!.putString("selected_language", selectedLanguageCode)
            Log.d("selected_language", selectedLanguageCode)
        }
    }
}

