package com.bitsTech.app.antithefttracker.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.flashLight.FlashingLightManager
import com.bitsTech.app.antithefttracker.intrface.UpdateUIListener
import com.bitsTech.app.antithefttracker.ui.activities.WindowActivity
import com.bitsTech.app.antithefttracker.vibration.VibrationManager
import com.bitsTech.solutions.app.antithefttracker.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FullChargingDecectService : Service() {
    private lateinit var fullyChargedStateReceiver: BroadcastReceiver
    private val channelId = "WifiStateChannelId"
    private val notificationId = 123

    private var disconnect = 0
    private var connect = 0
    private var isVibrate = false
    private var isFlash = false
    private var radioOnce = false
    private var radioAlways = false
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var vibrationManager: VibrationManager
    private lateinit var flashlightManager: FlashingLightManager
    private var isActivityStartd=false
    companion object{
        var isServiceRunning = false
    }
    var isOverlayWindowStart=false
    var overlayView: View? = null
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate() {
        Log.d("wifi_mananger", "onCreate: ")
        super.onCreate()
        createNotificationChannel()
        CoroutineScope(Dispatchers.Main).launch {
            UpdateUIListener.updateData(true)
        }
        isServiceRunning = true

        isFlash = MyApplication.prefs!!.getBoolean("FullCharging_FLASH", false)
        isVibrate = MyApplication.prefs!!.getBoolean("FullCharging_VIBRATE", false)
        // RadioButtons Handlers
        radioOnce = MyApplication.prefs!!.getBoolean("isRadioOnce", false)
        radioAlways = MyApplication.prefs!!.getBoolean("isRadioAlways", false)
        vibrationManager=VibrationManager(this)
        flashlightManager= FlashingLightManager(this)

        val lastSelected =
            MyApplication.prefs!!.getString("selected_tone", R.raw.alert1.toString()).toString()
        mediaPlayer = MediaPlayer.create(this, lastSelected.toInt())

        fullyChargedStateReceiver = object : BroadcastReceiver() {
            @SuppressLint("SuspiciousIndentation")
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onReceive(context: Context?, intent: Intent?) {
                // Check battery state changes
                if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL

                    if (isCharging && !isActivityStartd) {
                        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                        val batteryPercentage = (level.toFloat() / scale.toFloat()) * 100
                        if (batteryPercentage == 100f) {
                            // Battery is fully charged
                           startAction()
                        }
                    }
                }
            }
        }
        registerReceiver(fullyChargedStateReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val notification=createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ServiceCompat.startForeground(this, 1, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            ) // Specify sensor type
        } else {
            // Handle foreground service for older versions (if necessary)
            startForeground(1, notification)
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    private fun startAction() {
        mediaPlayer.isLooping = radioAlways
        mediaPlayer.start()
        Handler(Looper.getMainLooper()).postDelayed({
           showOverlayWindow()
            if (isVibrate) {
                vibrationManager.startVibrate(700)
            }
            if (isFlash) {
                flashlightManager.startBlink()
            }
        }, 700)
    }
    private fun showOverlayWindow() {
        if (!isOverlayWindowStart) {
            val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            overlayView = layoutInflater.inflate(R.layout.activity_overlay_window, null)

            overlayView?.apply {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                )

                params.gravity = Gravity.START or Gravity.TOP


                val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                windowManager.addView(this, params)
                overlayView!!.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)

                // Set the status bar color to transparent

                setOnClickListener {
                    stopSelf()
                    dismissOverlayWindow()
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val windowInsetsController = overlayView?.windowInsetsController
                windowInsetsController?.hide(WindowInsets.Type.navigationBars())
                windowInsetsController?.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

            isOverlayWindowStart = true
        }
    }
    private fun dismissOverlayWindow() {
        if(overlayView != null) {
            GlobalScope.launch {
                withContext(Dispatchers.Main) {
                    val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                    windowManager.removeView(overlayView)
                    overlayView = null
                    isOverlayWindowStart = false
                }
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        Log.d("WIFI_STATE_SERVICE", "onDestroy: ")
        unregisterReceiver(fullyChargedStateReceiver)
        mediaPlayer.stop()
        vibrationManager.stopVibrate()
        flashlightManager.stopBlinking()
        isActivityStartd=false
        isServiceRunning=false
            UpdateUIListener.updateData(false)
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Wifi State Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, WindowActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notificationBuilder: NotificationCompat.Builder =
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationCompat.Builder(this, channelId)
            } else {
                NotificationCompat.Builder(this)
            }

        return notificationBuilder
            .setContentTitle("Fully Charge Detecting...")
            .setContentText("tap to stop")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
    }

}