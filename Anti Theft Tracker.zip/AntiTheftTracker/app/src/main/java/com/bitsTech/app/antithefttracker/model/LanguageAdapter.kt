package com.bitsTech.app.antithefttracker.model

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bitsTech.solutions.app.antithefttracker.R

class LanguageAdapter  (
    private val context: Context,
    private val languages: List<Language>,
    private val onItemClick: (Language) -> Unit
) : RecyclerView.Adapter<LanguageAdapter.LanguageViewHolder>() {

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private val selectedLanguageKey = "selectedLanguage"

    inner class LanguageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val languageName: TextView = itemView.findViewById(R.id.Name)
        val flagImage: ImageView = itemView.findViewById(R.id.Flag)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LanguageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_view, parent, false)
        return LanguageViewHolder(view)
    }

    @SuppressLint("ResourceType")
    override fun onBindViewHolder(holder: LanguageViewHolder, position: Int) {
        val language = languages[position]
        holder.languageName.text = language.name
        holder.flagImage.setImageResource(language.flagResource)

        // Retrieve the selected language from SharedPreferences
        val selectedLanguage = sharedPreferences.getString(selectedLanguageKey, "System Language")
        if (language.name == selectedLanguage) {
            holder.itemView.setBackgroundResource(R.drawable.linear2_bg)
        } else {
            holder.itemView.setBackgroundResource(R.drawable.linear_bg)
        }
        holder.itemView.setOnClickListener {
            sharedPreferences.edit().putString(selectedLanguageKey, language.name).apply()
            notifyDataSetChanged()
            onItemClick(language)
        }
    }
    override fun getItemCount(): Int {
        return languages.size
    }
    // Function to get the selected language
    fun getSelectedLanguage(): Language? {
        val selectedLanguage = sharedPreferences.getString(selectedLanguageKey, "System Language")
        return languages.find { it.name == selectedLanguage }
    }
}