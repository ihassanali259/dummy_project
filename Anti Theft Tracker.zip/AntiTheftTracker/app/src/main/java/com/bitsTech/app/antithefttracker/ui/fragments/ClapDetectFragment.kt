package com.bitsTech.app.antithefttracker.ui.fragments

import android.annotation.SuppressLint
import android.app.ActionBar
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.airbnb.lottie.LottieDrawable
import com.bitsTech.app.ads.AppInterstitialAds
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.flashLight.FlashingLightManager
import com.bitsTech.app.antithefttracker.intrface.UpdateUIListener
import com.bitsTech.app.antithefttracker.services.AntiPocketService
import com.bitsTech.app.antithefttracker.services.ChargerPluginService
import com.bitsTech.app.antithefttracker.services.ClapDetectorService
import com.bitsTech.app.antithefttracker.services.FullChargingDecectService
import com.bitsTech.app.antithefttracker.services.HandFreeDetectService
import com.bitsTech.app.antithefttracker.services.MotionDetectionService
import com.bitsTech.app.antithefttracker.services.WhistleDetectService
import com.bitsTech.app.antithefttracker.services.WifiStateService
import com.bitsTech.app.antithefttracker.ui.activities.SplashActivity
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.FragmentClapDetectionBinding
import com.bitsTech.solutions.app.antithefttracker.databinding.FragmentWhistleDetectionBinding
import com.bitsTech.solutions.app.antithefttracker.databinding.PermissionDialogBinding
import com.bitsTech.solutions.app.antithefttracker.databinding.SettingBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.radiobutton.MaterialRadioButton
import kotlinx.coroutines.*

class ClapDetectFragment : Fragment(), UpdateUIListener.Listener {
    private lateinit var binding: FragmentClapDetectionBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var bottomSheet: BottomSheetDialog
    private var mediaPlayer: MediaPlayer? = null
    private var radioOnce = false
    private var radioAlways = false
    private var volume = 5
    private val settingBottomSheetBinding by lazy {
        SettingBottomSheetBinding.inflate(layoutInflater)
    }
    private val permissionDialogBinding by lazy {
        PermissionDialogBinding.inflate(layoutInflater)
    }
    private lateinit var dialog: Dialog

    companion object {
        var isFlash = false
        var isVibrate = false
        var isStartingAction = false
        var isPerformingAction = false
        val coroutineScope = CoroutineScope(Dispatchers.Main)
        private const val PERMISSION_RECORD_AUDIO = android.Manifest.permission.RECORD_AUDIO
        private const val AUDIO_PERMISSION_REQUEST_CODE = 100
    }


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentClapDetectionBinding.inflate(layoutInflater)

        val flashlightManager = FlashingLightManager(requireContext())
        binding.lottieAnimationView.repeatCount = LottieDrawable.INFINITE

        if (!isAudioRecordingPermissionGranted(requireContext())) {

            showPermissionDialog()
        }

        if (!ClapDetectorService.isServiceRunning) {
            binding.imgActivate.visibility = View.VISIBLE
            binding.imgActivate.text = getString(R.string.activated)
            binding.imgActivate.isClickable = true
            binding.txtStop.visibility = View.INVISIBLE
        } else {
            binding.imgActivate.text = ""
            binding.imgActivate.visibility = View.INVISIBLE
            binding.txtStop.visibility = View.VISIBLE
        }
        val intent = Intent(requireContext(), ClapDetectorService::class.java)
        sharedPreferences =
            requireContext().getSharedPreferences("MY_ShHARED_FILE", Context.MODE_PRIVATE)

        getFlashStatus()
        getVibrateStatus()
        getSelectedVolume()
        initializeBottomSheet()
        radioOnce = MyApplication.prefs!!.getBoolean("isRadioOnce", true)
        settingBottomSheetBinding.radioOnce.isChecked = radioOnce
        radioAlways = MyApplication.prefs!!.getBoolean("isRadioAlways", false)
        settingBottomSheetBinding.radioAlways.isChecked = radioAlways
        binding.apply {
            //   AppNativeAds.inflateSmallAds(requireContext(), frameLayoutAds)
            val adNativeID = if (SplashActivity.isBundleDebug) {
                "ca-app-pub-3940256099942544/2247696110"
            } else {
                "ca-app-pub-4992414586834585/1577841670"
            }
            Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
//            AppNativeAds.loadAndInflateSmallNativeAdMob(
//                requireContext(),
//                adNativeID,
//                binding.frameLayoutAds
//            )
            cardwhistle.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_clapDetectFragment_to_whistleDetection)
//                    }
//                }
            }
            cardHandsFreeDetect.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_clapDetectFragment_to_handFreeDetect)
//                    }
//                }
            }
            ChargerRemoval.setOnClickListener {
//                AppInterstitialAds.showInterAd(requireContext()) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                findNavController().navigate(R.id.action_clapDetectFragment_to_chargerDetection)
//                    }
//                }
            }
            imgActivate.setOnClickListener {
                if (!permissionOK()) {
                    openDialog()
                } else {
                    if (!isAudioRecordingPermissionGranted(requireContext())) {
                        showPermissionDialog()
                    } else {
                        //  AppInterstitialAds.showInterAd(requireActivity()) {
                        val wifiService = Intent(requireContext(), WifiStateService::class.java)
                        val fullChargingService =
                            Intent(requireContext(), FullChargingDecectService::class.java)
                        val motionService =
                            Intent(requireContext(), MotionDetectionService::class.java)
                        val chargerPlugingDetection =
                            Intent(requireContext(), ChargerPluginService::class.java)
                        val antiPocketDetect =
                            Intent(requireContext(), AntiPocketService::class.java)
                        val handFreeDetect =
                            Intent(requireContext(), HandFreeDetectService::class.java)
                        CoroutineScope(Dispatchers.Main).launch {
                            isStartingAction = true
                            delay(6000)

                            if (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    WifiStateService::class.java
                                ) ||
                                (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    FullChargingDecectService::class.java
                                )) ||
                                (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    MotionDetectionService::class.java
                                )) ||
                                (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    ChargerPluginService::class.java
                                )) ||
                                (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    AntiPocketService::class.java
                                ))
                                ||
                                (flashlightManager.isServiceRunning(
                                    requireContext(),
                                    HandFreeDetectService::class.java
                                ))
                            ) {
                                requireActivity().stopService(wifiService)
                                requireActivity().stopService(fullChargingService)
                                requireContext().stopService(motionService)
                                requireActivity().stopService(chargerPlugingDetection)
                                requireActivity().stopService(antiPocketDetect)
                                requireContext().stopService(handFreeDetect)
                            }
                            isStartingAction = false
                        }
                        imgActivate.isClickable = false
                        isPerformingAction = true
                        imgActivate.text = ""
                        if (!ClapDetectorService.isServiceRunning) {
                            imgActivate.text = " "
                        }
                        coroutineScope.launch {
                            lottieCount.visibility = View.VISIBLE
                            lottieCount.playAnimation()
                            delay(5500)
                            requireContext().startForegroundService(intent)
                            sharedPreferences.edit().putBoolean("isbtnStop", true).apply()
                            binding.txtStop.visibility = View.VISIBLE
                            binding.imgActivate.visibility = View.INVISIBLE
                        }
                    }
                }
                //  }
            }
            txtStop.setOnClickListener {
                //   AppInterstitialAds.showInterAd(requireContext()) {
                txtStop.visibility = View.INVISIBLE
                imgActivate.visibility = View.VISIBLE
                imgActivate.isClickable = true
                imgActivate.text = "activate"
                requireContext().stopService(intent)
                //   }
            }
            imgbtnMenu.setOnClickListener {
                if (isStartingAction) {
                    Toast.makeText(
                        requireContext(),
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(requireContext()) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    findNavController().popBackStack()
//                        }
//                    }
                }
            }
            btnAlarmSetting.setOnClickListener {
                showAlarmBottomSheet()
                // findNavController().navigate(R.id.action_whistleDetection_to_alarmSettingFragment)
            }
            switchFlash.setOnClickListener {
                isFlash = !isFlash
                if (isFlash) {
                    switchFlash.setImageResource(R.drawable.toggle_on)
                    MyApplication.prefs!!.putBoolean("clapFlash", true)
                } else {
                    switchFlash.setImageResource(R.drawable.switch_icon)
                    MyApplication.prefs!!.putBoolean("clapFlash", false)
                }

            }
            switchVibrate.setOnClickListener {
                isVibrate = !isVibrate
                if (isVibrate) {
                    switchVibrate.setImageResource(R.drawable.toggle_on)
                    MyApplication.prefs!!.putBoolean("clapVibrate", true)
                } else {
                    switchVibrate.setImageResource(R.drawable.switch_icon)
                    MyApplication.prefs!!.putBoolean("clapVibrate", false)
                }
            }
        }
        return binding.root
    }

    private fun isAudioRecordingPermissionGranted(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            PERMISSION_RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioRecordingPermission(activity: Activity) {
        AppInterstitialAds.isInterstitialAdsShowing = true
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(PERMISSION_RECORD_AUDIO),
            AUDIO_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST_CODE && grantResults.isNotEmpty()) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //
            } else if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                findNavController().popBackStack()
            }
        }
        AppInterstitialAds.isInterstitialAdsShowing = false
    }

    private fun showPermissionDialog() {
        val builder = MaterialAlertDialogBuilder(requireContext())
        builder.setTitle("Permission Required")
        builder.setMessage("This feature requires microphone permission. Please grant the permission to continue.")
        builder.setPositiveButton("Grant") { dialog, _ ->
            requestAudioRecordingPermission(requireActivity())
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
            findNavController().popBackStack()
            // Handle cancellation if needed
        }
        builder.setCancelable(false)
        builder.show()
    }

    override fun onResume() {
        super.onResume()

        UpdateUIListener.listener = this@ClapDetectFragment
        if (!ClapDetectorService.isServiceRunning) {
            binding.imgActivate.visibility = View.VISIBLE
            binding.imgActivate.text = "activate"
            binding.imgActivate.isClickable = true
            binding.txtStop.visibility = View.INVISIBLE
        } else {
            binding.imgActivate.visibility = View.INVISIBLE
            binding.txtStop.visibility = View.VISIBLE
        }
    }

    private fun initializeBottomSheet() {
        if (!::bottomSheet.isInitialized) {
            bottomSheet = BottomSheetDialog(requireContext())
            bottomSheet.setContentView(settingBottomSheetBinding.root)
        }
    }

    private fun showAlarmBottomSheet() {
        bottomSheet.show()
        settingBottomSheetBinding.apply {
            tone1.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                stopMediaPlayer()
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert1)
                mediaPlayer!!.start()
                MyApplication.prefs!!.putString("selected_tone", R.raw.alert1.toString())
            }
            tone2.setOnClickListener {

                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert2)
                mediaPlayer!!.start()
                MyApplication.prefs!!.putString("selected_tone", R.raw.alert2.toString())
            }
            tone3.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert3)
                mediaPlayer!!.start()

                MyApplication.prefs!!.putString("selected_tone", R.raw.alert3.toString())
            }
            tone4.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert4)
                mediaPlayer!!.start()

                MyApplication.prefs!!.putString("selected_tone", (R.raw.alert4.toString()))
            }
            tone5.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert5)
                mediaPlayer!!.start()
                MyApplication.prefs!!.putString("selected_tone", (R.raw.alert5.toString()))
            }
            tone6.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                    mediaPlayer?.reset()
                }
                mediaPlayer = MediaPlayer.create(requireContext(), R.raw.alert6)
                mediaPlayer!!.start()
                MyApplication.prefs!!.putString("selected_tone", (R.raw.alert6.toString()))
            }

            val lastSelected =
                MyApplication.prefs!!.getString("selected_tone", R.raw.alert1.toString())

            val materialRadio: MutableMap<String, MaterialRadioButton> = HashMap()
            materialRadio[java.lang.String.valueOf(R.raw.alert1)] = tone1
            materialRadio[java.lang.String.valueOf(R.raw.alert2)] = tone2
            materialRadio[java.lang.String.valueOf(R.raw.alert3)] = tone3
            materialRadio[java.lang.String.valueOf(R.raw.alert4)] = tone4
            materialRadio[java.lang.String.valueOf(R.raw.alert5)] = tone5
            materialRadio[java.lang.String.valueOf(R.raw.alert6)] = tone6

            val checkBox = materialRadio[lastSelected]
            if (checkBox != null) {
                checkBox.isChecked = true
            }
            radioOnce.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    MyApplication.prefs!!.putBoolean("isRadioOnce", true)
                } else {
                    MyApplication.prefs!!.putBoolean("isRadioOnce", false)
                }
            }
            radioAlways.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    MyApplication.prefs!!.putBoolean("isRadioAlways", true)
                } else {
                    MyApplication.prefs!!.putBoolean("isRadioAlways", false)
                }
            }
            seekbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                @SuppressLint("SetTextI18n")
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val audioManager =
                        context!!.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    volume = ((progress * maxVolume) / seekBar?.max!!)
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0)
                    volume = progress
                    settingBottomSheetBinding.textSeekbar.text = "Alarm Sensitivity: $volume"
                    MyApplication.prefs!!.putInt("alarmVolume", volume)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                }
            })
            btnOk.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                }
                bottomSheet.dismiss()
            }
            btnCancel.setOnClickListener {
                if (mediaPlayer?.isPlaying == true) {
                    mediaPlayer?.stop()
                }
                bottomSheet.dismiss()
            }
        }
    }

    private fun stopMediaPlayer() {
        mediaPlayer?.apply {
            if (isPlaying) {
                stop()
            }
            release()
        }
        mediaPlayer = null
    }

    @SuppressLint("SetTextI18n")
    private fun getSelectedVolume() {
        volume = MyApplication.prefs!!.getInt("alarmVolume", volume)
        settingBottomSheetBinding.seekbar.progress = volume
        settingBottomSheetBinding.textSeekbar.text = "Alarm Sensitivity: $volume"
    }

    private fun getFlashStatus() {
        isFlash = MyApplication.prefs!!.getBoolean("clapFlash", false)
        if (isFlash) {
            binding.switchFlash.setImageResource(R.drawable.toggle_on)
        } else {
            binding.switchFlash.setImageResource(R.drawable.switch_icon)
        }
    }

    private fun getVibrateStatus() {
        isVibrate = MyApplication.prefs!!.getBoolean("clapVibrate", false)
        if (isVibrate) {
            binding.switchVibrate.setImageResource(R.drawable.toggle_on)
        } else {
            binding.switchVibrate.setImageResource(R.drawable.switch_icon)
        }
    }

    private fun openDialog() {
        val view = permissionDialogBinding.root
        if (view.parent != null) {
            (view.parent as ViewGroup).removeView(view)
        }
        dialog = Dialog(requireContext(), ActionBar.LayoutParams.MATCH_PARENT)
        dialog.setContentView(view)
        dialog.window!!.setBackgroundDrawableResource(R.color.blur)
        dialog.window!!.setWindowAnimations(R.style.DialogUpToDownAnimation)
        dialog.show()
        permissionDialogBinding.apply {
            permissionDialogBinding.no.setOnClickListener {
                dialog.dismiss()
            }
            permissionDialogBinding.yes.setOnClickListener {
                dialog.dismiss()
                displayOverlayPermission()
            }
        }
    }

    private fun displayOverlayPermission() {
        val REQUEST_CODE = 101
        val myIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        myIntent.data = Uri.parse("package:${requireActivity().packageName}")
        startActivityForResult(myIntent, REQUEST_CODE)

    }

    private fun permissionOK(): Boolean {
        return Settings.canDrawOverlays(requireContext())
    }

    private fun openAppSettingsForPermissions(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        intent.data = Uri.fromParts("package", context.packageName, null)
        startActivity(intent)
    }

    override fun getData(isServiceRunning: Boolean) {
        with(binding) {
            if (isServiceRunning) {
                imgActivate.visibility = View.INVISIBLE
                txtStop.visibility = View.VISIBLE
            } else {
                //  requireActivity().recreate()
                imgActivate.visibility = View.VISIBLE
                imgActivate.text = "activate"
                imgActivate.isClickable = true
                txtStop.visibility = View.INVISIBLE
            }
        }
    }
}