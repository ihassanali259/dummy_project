package com.bitsTech.app.antithefttracker.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import androidx.recyclerview.widget.RecyclerView
import com.bitsTech.app.antithefttracker.model.Slider
import com.bitsTech.solutions.app.antithefttracker.R


class ViewPagerAdapter(private val list: List<Slider>):RecyclerView.Adapter<ViewPagerAdapter.ViewHolder>() {


    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val image:ImageView=itemView.findViewById(R.id.img_Slider)
        val text:TextView=itemView.findViewById(R.id.discription)
    }
    @SuppressLint("SuspiciousIndentation")
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
     val view=LayoutInflater.from(parent.context).inflate(R.layout.image_slider,parent,false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
       holder.image.setImageResource(list[position].img)
        holder.text.text=list[position].disp

    }
    override fun getItemCount(): Int {
       return list.size
    }


}