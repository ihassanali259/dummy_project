package com.bitsTech.app.ads

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.bitsTech.solutions.app.antithefttracker.R


import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.analytics.logEvent
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AppNativeAds {

    companion object {
        //        var maxNativeAd: MaxAd? = null
//        var maxNativeAdLoader: MaxNativeAdLoader? = null

        var amNativeAd: NativeAd? = null
        var runTimeNativeAdID:NativeAd?=null
        var onBoardingNative:NativeAd?=null
        var feedbackNativeAds:NativeAd?=null
        var dashBoardNative:NativeAd?=null
        var howToUseNative:NativeAd?=null
        fun initializeAdMobNativeAd(context: Context) {
            MobileAds.initialize(context) {}
        }

        var nativeRequesCounter = 0
      /*  fun loadAmNativeAdOnBoarding(context: Context, onAdAdLoadedCallback: (Boolean) -> Unit) {
            onBoardingNative = null
            Log.d("Native_Ads", "OnBoardingAmNativeSmall:-> ")
            nativeRequesCounter++

            val builder = AdLoader.Builder(context, context.getString(R.string.AM_NATIVE_ONBOARDING))
                .forNativeAd { nativeAd ->
                    onBoardingNative = nativeAd
                    onAdAdLoadedCallback.invoke(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                    }

                    override fun onAdFailedToLoad(p0: LoadAdError) {
                        super.onAdFailedToLoad(p0)
                        onAdAdLoadedCallback.invoke(false)
                        Log.e("Native_Ads", "OnBoarding_onAdError:failed-->Error Code:${p0.code} ")
                        Log.e("Native_Ads", "OnBoarding_onAdError:failed--Error Message:${p0.message} ")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                      //  Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}
                        loadAmNativeAdOnBoarding(context) {}
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.e("Native_Ads", "OnBoarding_onAdLoaded:")
                    }
                })
                .build()

            builder.loadAd(AdRequest.Builder().build())
        }
        fun loadAmNativeAdOnFeedback(context: Context, onAdAdLoadedCallback: (Boolean) -> Unit) {
            feedbackNativeAds = null
            Log.d("Native_Ads", "UserFeedback:->$onAdAdLoadedCallback ")
            nativeRequesCounter++

            val builder = AdLoader.Builder(context, context.getString(R.string.AM_NATIVE_USERFEEDBACK))
                .forNativeAd { nativeAd ->
                    feedbackNativeAds = nativeAd
                    onAdAdLoadedCallback.invoke(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                    }

                    override fun onAdFailedToLoad(p0: LoadAdError) {
                        super.onAdFailedToLoad(p0)
                        onAdAdLoadedCallback.invoke(false)
                        Log.e("Native_Ads", "UserFeedback_onAdError:failed-->Error Code:${p0.code} ")
                        Log.e("Native_Ads", "UserFeedback_onAdError:failed--Error Message:${p0.message} ")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        //  Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}
                        loadAmNativeAdOnBoarding(context) {}
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.e("Native_Ads", "UserFeedback__onAdLoaded:")
                    }
                })
                .build()

            builder.loadAd(AdRequest.Builder().build())
        }
        fun loadAmNativeAdOnHowToUse(context: Context, onAdAdLoadedCallback: (Boolean) -> Unit) {
            howToUseNative = null
            Log.d("Native_Ads", "HowToUse:->$onAdAdLoadedCallback ")
            nativeRequesCounter++

            val builder = AdLoader.Builder(context, context.getString(R.string.AM_NATIVE_HOWTOUSE))
                .forNativeAd { nativeAd ->
                    howToUseNative = nativeAd
                    onAdAdLoadedCallback.invoke(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                    }

                    override fun onAdFailedToLoad(p0: LoadAdError) {
                        super.onAdFailedToLoad(p0)
                        onAdAdLoadedCallback.invoke(false)
                        Log.e("Native_Ads", "HowToUse_onAdError:failed-->Error Code:${p0.code} ")
                        Log.e("Native_Ads", "HowToUse_onAdError:failed--Error Message:${p0.message} ")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                        //  Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}
                        loadAmNativeAdOnBoarding(context) {}
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.e("Native_Ads", "loadAmNativeAdOnHowToUse_onAdLoaded:")
                    }
                })
                .build()

            builder.loadAd(AdRequest.Builder().build())
        }*/
       /* fun loadAmNativeAd(context: Context, onAdAdLoadedCallback: (Boolean) -> Unit) {
            amNativeAd = null
            Log.d("Native_Ads", "loadAmNativeAd:->$onAdAdLoadedCallback ")
            nativeRequesCounter++
            val builder = AdLoader.Builder(context, context.getString(R.string.AM_NATIVE))
                .forNativeAd { nativeAd ->
                    amNativeAd = nativeAd
                    onAdAdLoadedCallback.invoke(true)
                }
                .withAdListener(object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                    }

                    override fun onAdFailedToLoad(p0: LoadAdError) {
                        super.onAdFailedToLoad(p0)
                        onAdAdLoadedCallback.invoke(false)
                        Log.e("Native_Ads", "Admob_onAdError:failed-->${p0.code} ")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                       // Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}
                        loadAmNativeAd(context) {}
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        Log.e("Native_Ads", "Amob_onAdLoaded:")
                    }
                })
                .build()

            builder.loadAd(AdRequest.Builder().build())
        }*/


        /*fun inflateSmallAds(context: Context, frameLayout: FrameLayout) {
            if (amNativeAd != null) {
                inflateSmallAdMobNative(context, frameLayout, amNativeAd)
                Log.d("ADMOD_APPlovin", "inflateBigAds:0$amNativeAd ")
            } else {
               // loadSmallAdmobNativeOnDemand(context, frameLayout)
               // loadSmallAdmobNativeOnDemand(context, frameLayout)
            }
        }*/
        private fun loadRunTimeSmallMobNativeAd(context: Context, adID: String, onAdAdLoadedCallback: (Boolean) -> Unit) {
            runTimeNativeAdID = null

            val builder = AdLoader.Builder(context, adID)
                .forNativeAd { nativeAd ->
                    runTimeNativeAdID = nativeAd

                }.withAdListener(object : AdListener() {
                    override fun onAdClosed() {
                        super.onAdClosed()
                    }

                    override fun onAdFailedToLoad(p0: LoadAdError) {
                        super.onAdFailedToLoad(p0)
                        onAdAdLoadedCallback.invoke(false)
                        Log.e("AM_NATIVE", "onAdError:failed-->${p0.code} ")
                    }

                    override fun onAdImpression() {
                        super.onAdImpression()
                          Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION){}
                        // loadRunTimeSmallMobNativeAd(){}
//                        AdManager.onAdsImpressions()
                    }

                    override fun onAdLoaded() {
                        super.onAdLoaded()
                        onAdAdLoadedCallback.invoke(true)
                        Log.e("AM_NATIVE", "onAdLoaded:native_ad_loaded ")
                    }
                }).build()

            builder.loadAd(AdRequest.Builder().build())
        }


        /*private fun inflateSmallAdMobNative(
            context: Context?, frameLayout: FrameLayout,
            admobnative: NativeAd?,
        ) {
            Log.d("Native_Ads", "inflateAdmobNativeSmall:$admobnative ")

            frameLayout.removeAllViews()
            frameLayout.visibility = View.VISIBLE
            var admobview: NativeAdView? = null

            admobview = LayoutInflater.from(context)
                .inflate(R.layout.small_ad_admob, null) as NativeAdView?
            frameLayout.addView(admobview)
            val contentview = admobview?.findViewById<LinearLayout>(R.id.adMod_layout)
            CoroutineScope(Dispatchers.Main).launch {
                delay(1000)
                        contentview?.visibility = View.VISIBLE
                // Set other ad assets.
            if(admobview != null) {
                admobview.mediaView = admobview.findViewById(R.id.AdMedia)
            }
                if(admobview != null) {
                    admobview.headlineView = admobview.findViewById(R.id.ad_headline)
                }
                if(admobview != null) {
                    admobview.bodyView = admobview.findViewById(R.id.ad_body)
                }
                if(admobview != null) {
                    admobview.callToActionView = admobview.findViewById(R.id.ad_call_to_action)
                }
                if(admobview != null) {
                    admobview.iconView = admobview.findViewById(R.id.ad_app_icon)
                }

                // The headline and media content are guaranteed to be in every UnifiedNativeAd.
                if(admobview != null) {
                    (admobview.headlineView as TextView).text = admobnative?.headline
                }
                admobnative?.mediaContent?.let { admobview?.mediaView?.setMediaContent(it) }

                if(admobnative?.body == null) {
                    if(admobview != null) {
                        admobview.bodyView?.visibility = View.INVISIBLE
                    }
                } else {
                    if(admobview != null) {
                        admobview.bodyView?.visibility = View.VISIBLE
                    }
                    if(admobview != null) {
                        (admobview.bodyView as TextView).text = admobnative.body
                    }
                }

                if(admobnative?.callToAction == null) {
                    if(admobview != null) {
                        admobview.callToActionView?.visibility = View.INVISIBLE
                    }
                } else {
                    if(admobview != null) {
                        admobview.callToActionView?.visibility = View.VISIBLE
                    }
                    if(admobview != null) {
                        (admobview.callToActionView as TextView).text = admobnative.callToAction
                    }
                }

                if(admobnative?.icon == null) {
                    if(admobview != null) {
                        admobview.iconView?.visibility = View.GONE
                    }
                } else {
                    (admobview?.iconView as ImageView).setImageDrawable(
                        admobnative.icon?.drawable
                    )
                    admobview.iconView?.visibility = View.VISIBLE
                }

                if(admobnative != null) {

                    admobview?.setNativeAd(admobnative)

                }

            }
        }*/
    
        private fun inflateSmallWhenLoad(context: Context?, admob: FrameLayout, admobnative: NativeAd?) {
            // Inflate a layout and add it to the parent ViewGroup.
            admob.removeAllViews()
            admob.visibility = View.VISIBLE
            var admobview: NativeAdView? = null
    
            admobview = LayoutInflater.from(context)
                .inflate(R.layout.small_ad_admob, null) as NativeAdView?
            admob.addView(admobview)
            val contentview = admobview?.findViewById<LinearLayout>(R.id.adMod_layout)
            /* CoroutineScope(Dispatchers.Main).launch {
                 delay(1000)*/
            contentview?.visibility = View.VISIBLE
            // Set other ad assets.
//            if(admobview != null) {
//                admobview.mediaView = admobview.findViewById(R.id.AdMedia)
//            }
            if (admobview != null) {
                admobview.headlineView = admobview.findViewById(R.id.ad_headline)
            }
            if (admobview != null) {
                admobview.bodyView = admobview.findViewById(R.id.ad_body)
            }
            if (admobview != null) {
                admobview.callToActionView = admobview.findViewById(R.id.ad_call_to_action)
            }
            if (admobview != null) {
                admobview.iconView = admobview.findViewById(R.id.ad_app_icon)
            }
    
            // The headline and media content are guaranteed to be in every UnifiedNativeAd.
            if (admobview != null) {
                (admobview.headlineView as TextView).text = admobnative?.headline
            }
            admobnative?.mediaContent?.let { admobview?.mediaView?.setMediaContent(it) }
    
            if (admobnative?.body == null) {
                if (admobview != null) {
                    admobview.bodyView?.visibility = View.INVISIBLE
                }
            } else {
                if (admobview != null) {
                    admobview.bodyView?.visibility = View.VISIBLE
                }
                if (admobview != null) {
                    (admobview.bodyView as TextView).text = admobnative.body
                }
            }
    
            if (admobnative?.callToAction == null) {
                if (admobview != null) {
                    admobview.callToActionView?.visibility = View.INVISIBLE
                }
            } else {
                if (admobview != null) {
                    admobview.callToActionView?.visibility = View.VISIBLE
                }
                if (admobview != null) {
                    (admobview.callToActionView as TextView).text = admobnative.callToAction
                }
            }
    
            if (admobnative?.icon == null) {
                if (admobview != null) {
                    admobview.iconView?.visibility = View.GONE
                }
            } else {
                (admobview?.iconView as ImageView).setImageDrawable(
                    admobnative.icon?.drawable
                )
                admobview.iconView?.visibility = View.VISIBLE
            }
    
            if (admobnative != null) {
        
                admobview?.setNativeAd(admobnative)
        
            }
        }
        fun loadAndInflateSmallNativeAdMob(context: Context,adID: String, admob: FrameLayout){
            loadRunTimeSmallMobNativeAd(context,adID){
                inflateSmallWhenLoad(context,admob, runTimeNativeAdID)
            }
        }
    }
}

