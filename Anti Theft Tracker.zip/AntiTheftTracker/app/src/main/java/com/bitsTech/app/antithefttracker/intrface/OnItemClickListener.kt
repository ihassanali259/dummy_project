package com.bitsTech.app.antithefttracker.intrface

interface OnItemClickListener {
    fun onItemClick(position: Int)
}