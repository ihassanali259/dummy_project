package com.bitsTech.app.antithefttracker.services

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.os.*
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.app.antithefttracker.flashLight.FlashingLightManager
import com.bitsTech.app.antithefttracker.intrface.UpdateUIListener
import com.bitsTech.app.antithefttracker.model.DetectorThread
import com.bitsTech.app.antithefttracker.model.OnWaveDetectedListener
import com.bitsTech.app.antithefttracker.model.RecorderThread
import com.bitsTech.app.antithefttracker.ui.activities.WindowActivity
import com.bitsTech.app.antithefttracker.vibration.VibrationManager
import com.bitsTech.solutions.app.antithefttracker.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class WhistleDetectService:  Service(), OnWaveDetectedListener {
    private val channelId = "WhistleDetectionChannelId"
    private val notificationId = 123

    private var isVibrate = false
    private var isFlash = false
    private var radioOnce = false
    private var radioAlways = false
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var vibrationManager: VibrationManager
    private lateinit var flashlightManager: FlashingLightManager
    private var isActivityStarted = false
    private var detectorThread: DetectorThread? = null
    private var recorderThread: RecorderThread? = null
    private val DETECT_NONE = 0
    private val DETECT_WHISTLE = 1
    private var selectedDetection = DETECT_NONE
    private  var lastSelected :String?=null
    companion object {
        var isServiceRunning = false }
    private var isOverlayWindowStart=false
    private var overlayView: View? = null

   /* private fun getnextInt(): Int {
        return seed.getAndIncrement()
    }*/
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAction()
       CoroutineScope(Dispatchers.Main).launch {
           UpdateUIListener.updateData(true)
       }
        isServiceRunning = true
         lastSelected =
            MyApplication.prefs!!.getString("selected_tone", R.raw.alert1.toString())
       mediaPlayer = MediaPlayer.create(this, lastSelected!!.toInt())
        isFlash=MyApplication.prefs!!.getBoolean("whistleFlash",false)
        isVibrate=MyApplication.prefs!!.getBoolean("whistleVibrate",false)
        radioAlways = MyApplication.prefs!!.getBoolean("isRadioAlways", false)
        radioOnce = MyApplication.prefs!!.getBoolean("isRadioOnce", false)
        vibrationManager = VibrationManager(this)
        flashlightManager = FlashingLightManager(this)


        val notification=createNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ServiceCompat.startForeground(this, 1, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            ) // Specify sensor type
        } else {
            // Handle foreground service for older versions (if necessary)
            startForeground(1, notification)
        }
    }

    private fun showOverlayWindow() {
        if (!isOverlayWindowStart) {
            val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            overlayView = layoutInflater.inflate(R.layout.activity_overlay_window, null)

            overlayView?.apply {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                )

                params.gravity = Gravity.START or Gravity.TOP


                val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                windowManager.addView(this, params)
                overlayView!!.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)

                // Set the status bar color to transparent

                setOnClickListener {
                    stopSelf()
                    dismissOverlayWindow()
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val windowInsetsController = overlayView?.windowInsetsController
                windowInsetsController?.hide(WindowInsets.Type.navigationBars())
                windowInsetsController?.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

            isOverlayWindowStart = true
        }
    }
    private fun dismissOverlayWindow() {
        if(overlayView != null) {
            GlobalScope.launch {
                withContext(Dispatchers.Main) {
                    val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
                    windowManager.removeView(overlayView)
                    overlayView = null
                    isOverlayWindowStart = false
                }
            }
        }
    }
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onWhistleDetected() {
        stopDetection()
        Log.e("Whistle", "Whistle Detected")
        mediaPlayer.start()
        mediaPlayer.isLooping=radioAlways
        Handler(Looper.getMainLooper()).postDelayed({
           showOverlayWindow()
            if (isVibrate) {
                vibrationManager.startVibrate(700)
            }
            if (isFlash) {
                flashlightManager.startBlink()
            }
        }, 700)
    }

    private fun stopActions() {
        mediaPlayer.stop()
        vibrationManager.stopVibrate()
        flashlightManager.stopBlinking()
        isActivityStarted = false
    }

    override fun onDestroy() {
        super.onDestroy()
//        whistleDetector.stop()
        stopActions()
        isServiceRunning = false
        CoroutineScope(Dispatchers.Main).launch {
            UpdateUIListener.updateData(false)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun startAction() {
        selectedDetection = DETECT_WHISTLE
        recorderThread = RecorderThread()
        recorderThread!!.start()
        detectorThread = DetectorThread(recorderThread!!)
        detectorThread!!.setOnSignalsDetectedListener(this)
        detectorThread!!.start()
    }
    private fun stopDetection() {
        recorderThread!!.stopRecording()
        recorderThread = null
        detectorThread!!.stopDetection()
        detectorThread = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Whistle Detection Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, WindowActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)

        val notificationBuilder: NotificationCompat.Builder =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationCompat.Builder(this, channelId)
            } else {
                NotificationCompat.Builder(this)
            }

        return notificationBuilder
            .setContentTitle("Whistle Detecting..")
            .setContentText("Tap to stop")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
    }
}