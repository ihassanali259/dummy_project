package com.bitsTech.app.antithefttracker.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.bitsTech.solutions.app.antithefttracker.BuildConfig
import androidx.appcompat.app.AppCompatDelegate
import com.akexorcist.localizationactivity.ui.LocalizationActivity
import com.bitsTech.app.ads.AppInterstitialAds
import com.bitsTech.app.antithefttracker.application.MyApplication
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivitySplashBinding
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.analytics.ktx.logEvent
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : LocalizationActivity() {
    private lateinit var binding: ActivitySplashBinding
    private val sharedPreferences by lazy {
        getSharedPreferences("MyThemePrefs", MODE_PRIVATE)
    }
    private lateinit var consentInformation: ConsentInformation
    var updateCompleted = false

    companion object {
        var isBundleDebug = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        if (sharedPreferences.getBoolean("IS-DARK-MODE", true)) {
            Log.i("dark_", "onCreate: dark")
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            Log.i("dark_", "onCreate: light")
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        isBundleDebug = BuildConfig.DEBUG

        checkConsent()
        loadAds()
        CoroutineScope(Dispatchers.Main).launch {
            delay(8000)
            showInterstitialAds()
            binding.lottieLoading.cancelAnimation()
        }
    }

    private fun loadAds() {
        CoroutineScope(Dispatchers.Main).launch {
            //  AppInterstitialAds.loadAmInterstitial(this@SplashActivity)
            AppInterstitialAds.loadAmInterstitialSplash(this@SplashActivity) {
                Log.d(
                    "INTERSTICIAL_ADS_SPLASH",
                    "onCreate: $it"
                )
            }
        }
    }

    private fun showInterstitialAds() {
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG $isBundleDebug")
        AppInterstitialAds.showInterAdSplash(this@SplashActivity) {
            if (!MyApplication.prefs?.getBoolean("IS_OPENED", false)!!) {
                Log.d("SplashActivity_check", "Navigating to LanguageActivity")
                startActivity(Intent(this@SplashActivity, OnBoardingActivity::class.java))
            } else {
                if (MyApplication.prefs!!.getBoolean("UserFeedBack", true)) {
                    Log.d("SplashActivity_check", "Navigating to UserFeedBackActivity")
                    startActivity(Intent(this@SplashActivity, UserFeedbackActivity::class.java))
                    MyApplication.prefs!!.putBoolean("UserFeedBack", false)
                    finish()
                } else {
                    Log.d("SplashActivity_check", "Navigating to MainActivity")
                    startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                    finish()
                }
            }
        }
    }

    fun checkConsent() {
        // Create a ConsentRequestParameters object.

        val params = ConsentRequestParameters
            .Builder()
            .build()

        consentInformation = UserMessagingPlatform.getConsentInformation(this)
        consentInformation.requestConsentInfoUpdate(
            this,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(
                    this
                ) { loadAndShowError ->
                    // Consent gathering failed.


                    Log.w(
                        "CONSENT", String.format(
                            "%s: %s",
                            loadAndShowError?.errorCode,
                            loadAndShowError?.message
                        )
                    )
                    Firebase.analytics.logEvent("CONSENT_GRANTED") {}
                    // Consent has been gathered.
                }
            },
            {

                    requestConsentError ->
                // Consent gathering failed.

                Firebase.analytics.logEvent("CONSENT_ERROR") {}
                Log.w(
                    "CONSENT", String.format(
                        "%s: %s",
                        requestConsentError.errorCode,
                        requestConsentError.message
                    )
                )
            })
    }
}
