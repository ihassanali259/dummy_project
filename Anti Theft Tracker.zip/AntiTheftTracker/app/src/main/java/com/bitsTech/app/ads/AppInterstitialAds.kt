package com.bitsTech.app.ads

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.AdLoadinDialoagBinding
import com.bumptech.glide.Glide
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.analytics.logEvent
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppInterstitialAds {

    companion object {
        var adFullScreenClosed = false
        private var dialog: Dialog? = null
        var adRequest = 0
        var isInterstitialAdsShowing = false

        var isAdTimerEnabled = false

        var adTimerJob: Job? = null
        var amInterAD: InterstitialAd? = null
        var amInterAdSplash: InterstitialAd? = null
        var amInterAdExit: InterstitialAd? = null
        
        fun loadAmInterstitialSplash(context: Context, onAdLoadedCallback: (Boolean) -> Unit) {
            if (amInterAdSplash != null)
                amInterAdSplash = null
            adFullScreenClosed = false
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                context.getString(R.string.AM_INTER_SPLASH_AD_ID),
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("Interstitial_ADS", adError.message)
                        amInterAdSplash = null
                        onAdLoadedCallback.invoke(false)
                        Log.d("Interstitial_ADS", "onAdFailedToLoad:$adError ")
                    }
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        Log.d("Interstitial_ADS", "Ad Loaded")
                        amInterAdSplash = interstitialAd
                        onAdLoadedCallback.invoke(true)
                    }
                })
        }
        fun showInterAdSplash(context: Context, adCloseCallback: (Boolean) -> Unit) {
            val ctx = context as Activity
            if (amInterAdSplash != null) {
                Log.d("Intersticial_Admob", "showInterAd: ")
                if (!ctx.isDestroyed && !ctx.isFinishing) {
                    showDialog(ctx)
                    amInterAdSplash!!.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                Log.d("Intersticial_Ads", "onAdDismissedFullScreenContent: ")
                                super.onAdDismissedFullScreenContent()
                                adCloseCallback.invoke(true)
                                isInterstitialAdsShowing = false
                                adFullScreenClosed = true

                            }
                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                isInterstitialAdsShowing = true
                                Log.d("Intersticial_Ads", "onAdShowedFullScreenContent: ")
                            }

                            override fun onAdImpression() {
                                super.onAdImpression()
                                Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}

                            }
                        }

                    CoroutineScope(Dispatchers.Default).launch {
                        delay(700)
                        withContext(Dispatchers.Main) {
                            hideDialog(context)
                            if (amInterAdSplash != null) {
                                amInterAdSplash!!.show(context as Activity)
                            }
                        }
                    }
                }
            }
            else {
                adCloseCallback.invoke(false)
            }

        }

        //load and show intersticial Ads on exit
        fun loadAmInterstitialExit(context: Context, onAdLoadedCallback: (Boolean) -> Unit) {
            if (amInterAdExit != null)
                amInterAdExit = null
            adFullScreenClosed = false
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                context.getString(R.string.AM_EXIT_INTERSTITIAL),
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("Interstitial_ADS", adError.message)
                        amInterAdExit = null
                        onAdLoadedCallback.invoke(false)
                        Log.d("Interstitial_ADS", "onAdFailedToLoad:$ ")
                    }
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        Log.d("Interstitial_ADS", "Ad Loaded")
                        amInterAdExit = interstitialAd
                        onAdLoadedCallback.invoke(true)
                    }
                })
        }
        fun showInterAdExit(context: Context, adCloseCallback: (Boolean) -> Unit) {
            val ctx = context as Activity
            if (amInterAdExit != null) {
                Log.d("Intersticial_Admob", "showInterAd: ")
                if (!ctx.isDestroyed && !ctx.isFinishing) {
                    showDialog(ctx)
                    amInterAdExit!!.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                Log.d("Intersticial_Ads", "onAdDismissedFullScreenContent: ")
                                super.onAdDismissedFullScreenContent()
                                loadAmInterstitialExit(ctx){}
                                adCloseCallback.invoke(true)
                                isInterstitialAdsShowing = false
                                adFullScreenClosed = true

                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                                isInterstitialAdsShowing = true
                                Log.d("Intersticial_Ads", "onAdShowedFullScreenContent: ")
                            }

                            override fun onAdImpression() {
                                super.onAdImpression()
                                Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}

                            }
                        }

                    CoroutineScope(Dispatchers.Default).launch {
                        delay(1500)
                        withContext(Dispatchers.Main) {
                            hideDialog(context)
                            if (amInterAdExit != null) {
                                amInterAdExit!!.show(context as Activity)
                            }
                        }
                    }
                }
            }
            else {
                adCloseCallback.invoke(false)
            }

        }
        fun loadAmInterstitial(context: Context) {
            if (amInterAD != null)
                amInterAD = null
            adFullScreenClosed = false
            val adRequest = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                context.getString(R.string.AM_INNTER_INTERSTITIAL),
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.d("Interstitial_ADS", adError.message)
                        amInterAD = null

                        Log.d("Interstitial_ADS", "onAdFailedToLoad:$ ")


                    }

                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        Log.d("Interstitial_ADS", "Ad Loaded")
                        amInterAD = interstitialAd
                    }
                })
        }
        fun showInterAd(context: Context, adCloseCallback: (Boolean) -> Unit) {
            if (isAdTimerEnabled) {
                adCloseCallback.invoke(true)
                return
            }

            val ctx = context as Activity
            if (amInterAD != null) {
                Log.d("Intersticial_Admob", "showInterAd: ")
                if (!ctx.isDestroyed && !ctx.isFinishing) {
                    showDialog(ctx)
                    amInterAD!!.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            Log.d("Intersticial_Ads", "onAdDismissedFullScreenContent: ")
                            super.onAdDismissedFullScreenContent()
                            adCloseCallback.invoke(true)
                            loadAmInterstitial(context)
                            isInterstitialAdsShowing = false
                            adFullScreenClosed = true

                        }

                        override fun onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent()
                            isInterstitialAdsShowing = true
                            startAdTimer()
                            Log.d("Intersticial_Ads", "onAdShowedFullScreenContent: ")
                        }

                        override fun onAdImpression() {
                            super.onAdImpression()
                          Firebase.analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION) {}

                        }
                    }

                    CoroutineScope(Dispatchers.Default).launch {
                        delay(1000)
                        withContext(Dispatchers.Main) {
                            hideDialog(context)
                            if (amInterAD != null) {
                                amInterAD!!.show(context as Activity)
                            }
                        }
                    }
                }
            }  else {
                loadAmInterstitial(context)
                adCloseCallback.invoke(false)
            }

        }

        private fun showDialog(context: Context) {
            val ctx = context as Activity
            if (!ctx.isDestroyed && !ctx.isFinishing) {
                val binding = AdLoadinDialoagBinding.inflate(LayoutInflater.from(context))
                dialog = Dialog(context)
                dialog!!.setContentView(binding.root)
                dialog!!.setCancelable(false)
                dialog!!.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                Glide.with(context as Context).load(R.drawable.loading).into(binding.loadingImage)
                dialog!!.show()
            }
        }
        private fun hideDialog(context: Context) {
            val ctx = context as Activity
            if (!ctx.isDestroyed && !ctx.isFinishing) {
                if (dialog != null) {
                    dialog!!.dismiss()
                }
            }
        }

        fun startAdTimer() {
            isAdTimerEnabled = true
            if (adTimerJob != null)
                adTimerJob = null

            adTimerJob = CoroutineScope(Dispatchers.Default).launch {
                delay(30000)
                isAdTimerEnabled = false
            }
        }

        fun cancelAdTimer() {
            if (adTimerJob == null)
                return
            adTimerJob?.cancel()

        }
    }
}
