package com.bitsTech.app.antithefttracker.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivityUserfeedbackBinding

class UserFeedbackActivity : AppCompatActivity() {
    private lateinit var binding:ActivityUserfeedbackBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding= ActivityUserfeedbackBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val adNativeID=if(SplashActivity.isBundleDebug){
            "ca-app-pub-3940256099942544/2247696110"
        }else{
            //real  ca-app-pub-4992414586834585/7438791026
            "ca-app-pub-4992414586834585/6971668965"
        }
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")

     //   AppNativeAds.loadAndInflateSmallNativeAdMob(this,adNativeID, binding.framelayoutAds)
        binding.apply {
            antiTheft.setOnClickListener {
                checkBoxAntiTheft.isChecked = !binding.checkBoxAntiTheft.isChecked
            }
            motionDetection.setOnClickListener {
                checkBoxmotionDetection.isChecked = !binding.checkBoxmotionDetection.isChecked
            }
            fullBattery.setOnClickListener {
                checkBoxfullBattery.isChecked = !binding.checkBoxfullBattery.isChecked
            }
            RemoveCharger.setOnClickListener {
                checkBoxRemoveCharger.isChecked = !checkBoxRemoveCharger.isChecked
            }
            Wifi.setOnClickListener {
                checkBoxWifi.isChecked = !checkBoxWifi.isChecked
            }
            handfree.setOnClickListener {
                checkBoxHandfree.isChecked = !checkBoxHandfree.isChecked
            }
            Whistle.setOnClickListener {
                checkBoxWhistle.isChecked = !checkBoxWhistle.isChecked
            }
        }
        binding.nextButton.setOnClickListener {
            if (binding.checkBoxAntiTheft.isChecked
                or
                binding.checkBoxmotionDetection.isChecked
                or
                binding.checkBoxfullBattery.isChecked
                or
                binding.checkBoxRemoveCharger.isChecked
                or
                binding.checkBoxWifi.isChecked
                or
                binding.checkBoxHandfree.isChecked
                or  binding.checkBoxWhistle.isChecked
            ) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Please choose at least one option", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        //do nothing
    }
}