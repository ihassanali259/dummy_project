package com.bitsTech.app.antithefttracker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.bitsTech.app.antithefttracker.ui.activities.LockScreenActivity

class LockScreenReceiver:BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // Start the LockScreenActivity when this receiver receives a broadcast
        val lockScreenIntent = Intent(context, LockScreenActivity::class.java)
        lockScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        context?.startActivity(lockScreenIntent)
    }
}