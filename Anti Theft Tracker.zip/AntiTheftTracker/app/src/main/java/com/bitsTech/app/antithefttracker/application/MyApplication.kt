package com.bitsTech.app.antithefttracker.application

import android.content.Context
import com.akexorcist.localizationactivity.ui.LocalizationApplication
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.ads.AppOpenManager
import com.bitsTech.app.antithefttracker.model.Prefs
import java.util.Locale

class MyApplication : LocalizationApplication() {
  //  private lateinit var appOpenManager: AppOpenManager

    companion object {
        var prefs: Prefs? = null
    }

    override fun getDefaultLanguage(context: Context): Locale {
        return Locale.getDefault()
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        AppNativeAds.initializeAdMobNativeAd(this)
    //    appOpenManager = AppOpenManager(this)
    }
}
