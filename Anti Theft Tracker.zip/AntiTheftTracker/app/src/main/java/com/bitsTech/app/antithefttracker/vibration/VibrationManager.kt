package com.bitsTech.app.antithefttracker.vibration

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.annotation.RequiresApi


class VibrationManager(context: Context){
    private var isVibrating=false
    private val vibrator=context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    @RequiresApi(Build.VERSION_CODES.O)
    fun startVibrate(duration: Long) {
        if (vibrator.hasVibrator()) {
            val pattern = longArrayOf(0, duration)
            vibrator.vibrate(
                VibrationEffect.createWaveform(
                    pattern,
                    0 // repeat indefinitely
                )
            )
            isVibrating = true
        }
    }

    fun stopVibrate() {
        if (isVibrating) {
            isVibrating = false

        }
        vibrator.cancel()
    }
}