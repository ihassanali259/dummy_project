package com.bitsTech.app.antithefttracker.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import com.akexorcist.localizationactivity.ui.LocalizationActivity
import com.bitsTech.app.ads.AppInterstitialAds
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.ads.AppOpenManager
import com.bitsTech.app.antithefttracker.ui.fragments.AntiPocketFragment
import com.bitsTech.app.antithefttracker.ui.fragments.ChargerPluginFragment
import com.bitsTech.app.antithefttracker.ui.fragments.ClapDetectFragment
import com.bitsTech.app.antithefttracker.ui.fragments.FullChargingDetectionFragment
import com.bitsTech.app.antithefttracker.ui.fragments.HandFreeDetect
import com.bitsTech.app.antithefttracker.ui.fragments.MotionDetectionFragment
import com.bitsTech.app.antithefttracker.ui.fragments.WhistleDetectFragment
import com.bitsTech.app.antithefttracker.ui.fragments.WifiDetectionFragment
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivityMainBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : LocalizationActivity() {
    private lateinit var binding: ActivityMainBinding
    private var exitDialog: BottomSheetDialog? = null
    private lateinit var updateResultLauncher: ActivityResultLauncher<IntentSenderRequest>
    private var appUpdateManager: AppUpdateManager? = null
    //  private lateinit var lockScreenReceiver: LockScreenReceiver

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateResultLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                finish()
            } else {
                // go with normal routine...
            }
        }


        checkUpdate()

        Log.d("MainActivity_lifecycle", "onCreate called")
        //     AppInterstitialAds.loadAmInterstitialExit(this@MainActivity){}

    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onResume() {
        super.onResume()
        // lockScreenReceiver = LockScreenReceiver()
        //  val filter = IntentFilter("anti.theft.alaram.donottouch.myphone.ACTION_SHOW_LOCK_SCREEN")
        //  registerReceiver(lockScreenReceiver, filter, RECEIVER_NOT_EXPORTED)
    }

    override fun onPause() {
        super.onPause()
        //  unregisterReceiver(lockScreenReceiver)
    }

    @SuppressLint("InflateParams", "MissingInflatedId")
    private fun showExitDialog() {
        exitDialog = BottomSheetDialog(this)
        exitDialog?.setContentView(R.layout.bottom_sheet)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            exitDialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
        } else {
            exitDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        val exitButton = exitDialog?.findViewById<Button>(R.id.yes)
        val cancelButton = exitDialog?.findViewById<Button>(R.id.no)
        val frameLayout = exitDialog?.findViewById<FrameLayout>(R.id.frameLayout_Ads_bottom)
        val adNativeID = if (SplashActivity.isBundleDebug) {
            "ca-app-pub-3940256099942544/2247696110"
        } else {
            //real   ca-app-pub-4992414586834585/1016852900
            "ca-app-pub-4992414586834585/1016852900"
        }
        Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
        // AppNativeAds.loadAndInflateSmallNativeAdMob(this, adNativeID, frameLayout!!)


        exitButton?.setOnClickListener {
            exitDialog?.dismiss()
            //this@MainActivity.finishAffinity()
            AppInterstitialAds.amInterAD = null
            AppInterstitialAds.cancelAdTimer()
            AppOpenManager.appOpenAd = null
            AppInterstitialAds.isInterstitialAdsShowing = false
            WindowActivity.isOverlayActiviOpen = false
            finishAffinity()
            //  finish()
        }

        cancelButton?.setOnClickListener {
            exitDialog?.dismiss()
        }
        exitDialog?.show()
    }

    companion object {
        var isAppDestroyed = false
    }

    override fun onBackPressed() {
        Log.d("MainActivity_lifecycle", "onBackPressed called")
        val navControler = Navigation.findNavController(this, R.id.fragmentContainerView)
        when (navControler.currentDestination!!.id) {
            R.id.clapDetectFragment -> {
                if (ClapDetectFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    )
                } else {
                    navControler.popBackStack()
                }
            }

            R.id.homeFragment -> {
                //  AppInterstitialAds.showInterAdExit(this@MainActivity) {
                showExitDialog()
                //  }
            }

            R.id.fullChargingDetectionFragment -> {
                if (FullChargingDetectionFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_fullChargingDetectionFragment_to_homeFragment)
//                            //navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.wifiDetectionFragment -> {
                if (WifiDetectionFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_wifiDetectionFragment_to_homeFragment)
//                            // navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.antiPocketDetectFragment -> {
                if (AntiPocketFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_antiPocketDetectFragment_to_homeFragment)
//                            // navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.chargerDetection -> {
                if (ChargerPluginFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_chargerDetection_to_homeFragment)
//                            //  navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.handFreeDetect -> {
                if (HandFreeDetect.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_handFreeDetect_to_homeFragment)
//                            // navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.whistleDetection -> {
                if (WhistleDetectFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_whistleDetection_to_homeFragment)
//                            // navControler.popBackStack()
//                        }
//                    }
                }
            }

            R.id.motionDetectionFragment -> {
                if (MotionDetectionFragment.isStartingAction) {
                    Toast.makeText(
                        this,
                        "Please wait while completing the action..",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
//                    AppInterstitialAds.showInterAd(this) {
//                        lifecycleScope.launch(Dispatchers.Main) {
//                            delay(100)
                    navControler.navigate(R.id.action_motionDetectionFragment_to_homeFragment)
//                        }
//                    }
                }
            }

            R.id.menuFragment -> {
//                AppInterstitialAds.showInterAd(this) {
//                    lifecycleScope.launch(Dispatchers.Main) {
//                        delay(100)
                navControler.popBackStack()
//                    }
//                }
            }
        }
    }

    override fun onDestroy() {
        Log.d("MainActivity_lifecycle", "onRestart called")
        super.onDestroy()
        isAppDestroyed = true
        AppInterstitialAds.amInterAD = null
        AppInterstitialAds.cancelAdTimer()
        AppOpenManager.appOpenAd = null
        AppInterstitialAds.isInterstitialAdsShowing = false
        WindowActivity.isOverlayActiviOpen = false
    }
    private fun checkUpdate() {
        appUpdateManager = AppUpdateManagerFactory.create(applicationContext)
        val appUpdateInfoTask = appUpdateManager!!.appUpdateInfo
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            ) {
                try {
                    val updateOptions = AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()
                    appUpdateManager!!.startUpdateFlowForResult(
                        appUpdateInfo,
                        updateResultLauncher,
                        updateOptions
                    )
                    // finish()
                } catch (e: Exception) {
                    e.printStackTrace()
                    Log.d("checkUpdate", "checkUpdate:${e.message.toString()} ")
                    // Proceed to the main activity even if there's an exception

                }
            } else {
                // No update available, proceed to the main activity

            }
        }
    }
}