package com.bitsTech.app.antithefttracker.ui.fragments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.bitsTech.app.ads.AppNativeAds
import com.bitsTech.app.antithefttracker.ui.activities.HowToUseActivity
import com.bitsTech.app.antithefttracker.ui.activities.OnBoardingActivity
import com.bitsTech.app.antithefttracker.ui.activities.SplashActivity
import com.bitsTech.solutions.app.antithefttracker.databinding.FragmentMenuBinding

class MenuFragment : Fragment() {
    private lateinit var binding: FragmentMenuBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMenuBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

             //   AppBannerAds.loadAMBanner(requireContext(),binding.frameLayoutBanner)

        binding.apply {
            // Native Ads
         //   AppNativeAds.inflateSmallAds(requireContext(), frameLayout)
            val adNativeID=if(SplashActivity.isBundleDebug){
                "ca-app-pub-3940256099942544/2247696110"
            }else{
                //real   ca-app-pub-4992414586834585/1016852900
                "ca-app-pub-4992414586834585/6201512779"
            }
            Log.d("BUNDLE_DEBUG", "onCreate:IS DEBUG ${SplashActivity.isBundleDebug}")
         //  AppNativeAds.loadAndInflateSmallNativeAdMob(requireContext(),adNativeID, binding.frameLayoutAds)
            constraintLayoutPrivacy.setOnClickListener {
                val privacyPolicyIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://sites.google.com/view/antitheftprivacypolicynew/home")
                )
                startActivity(privacyPolicyIntent)
            }
            imgbtnBack.setOnClickListener {
            findNavController().popBackStack()
            }

            constraintLayoutAlarmSetting.setOnClickListener {
                startActivity(Intent(requireContext(), HowToUseActivity::class.java))
            }
            constraintLayoutRateUs.setOnClickListener {
              rateUs()
            }
            constraintLayoutPassword.setOnClickListener {
                startActivity(Intent(requireContext(), OnBoardingActivity::class.java))
                requireActivity().finish()
            }
            constraintLayoutShare.setOnClickListener {
                shareApp(requireContext())
            }
        }
    }
    private fun rateUs() {
        val packageName =requireContext().packageName// Replace with your app's package name
        val uri = Uri.parse("market://details?id=$packageName")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun shareApp(context: Context) {
        val appPackageName = context.applicationInfo.packageName
        val appName = context.getString(com.bitsTech.solutions.app.antithefttracker.R.string.app_name)
        val shareBodyText = "https://play.google.com/store/apps/details?id=$appPackageName"

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, appName)
            putExtra(Intent.EXTRA_TEXT, shareBodyText)
        }
        context.startActivity(Intent.createChooser(sendIntent, null))
    }
}