package com.bitsTech.app.antithefttracker.ui.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import com.airbnb.lottie.LottieDrawable
import com.akexorcist.localizationactivity.ui.LocalizationActivity
import com.bitsTech.app.antithefttracker.flashLight.FlashingLightManager
import com.bitsTech.app.antithefttracker.services.AntiPocketService
import com.bitsTech.app.antithefttracker.services.ChargerPluginService
import com.bitsTech.app.antithefttracker.services.FullChargingDecectService
import com.bitsTech.app.antithefttracker.services.HandFreeDetectService
import com.bitsTech.app.antithefttracker.services.MotionDetectionService
import com.bitsTech.app.antithefttracker.services.WhistleDetectService
import com.bitsTech.app.antithefttracker.services.WifiStateService
import com.bitsTech.app.antithefttracker.vibration.VibrationManager
import com.bitsTech.solutions.app.antithefttracker.R
import com.bitsTech.solutions.app.antithefttracker.databinding.ActivityOverlayWindowBinding

class WindowActivity :LocalizationActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var flashlightManager:FlashingLightManager
    private lateinit var vibrationManager: VibrationManager
    lateinit var mediaPlayer: MediaPlayer
    companion object {
        var isOverlayActiviOpen = false

    }

    private lateinit var binding: ActivityOverlayWindowBinding
    override fun onStart() {
        super.onStart()
        isOverlayActiviOpen=true

    }
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOverlayWindowBinding.inflate(layoutInflater)
        isOverlayActiviOpen=true
        sharedPreferences = this.getSharedPreferences("MY_ShHARED_FILE", Context.MODE_PRIVATE)

        flashlightManager= FlashingLightManager(this)
        vibrationManager= VibrationManager(this)
        val lastSelected = sharedPreferences.getString("selected_tone", R.raw.alert1.toString())
        mediaPlayer= MediaPlayer.create(this,lastSelected!!.toInt())


        binding.lottieAnimationView.repeatCount=LottieDrawable.INFINITE

        binding.lottieAnimationView.setOnClickListener {
            finish()
            stopService(Intent(this, AntiPocketService::class.java))
            stopService(Intent(this, MotionDetectionService::class.java))
            stopService(Intent(this, FullChargingDecectService::class.java))
            stopService(Intent(this, ChargerPluginService::class.java))
            stopService(Intent(this, WifiStateService::class.java))
            stopService(Intent(this, WhistleDetectService::class.java))
            stopService(Intent(this, HandFreeDetectService::class.java))

            isOverlayActiviOpen = false
        }
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        isOverlayActiviOpen=true
    }
    override fun onBackPressed() {
        //do nothing
    }
    override fun onDestroy() {
        super.onDestroy()
        isOverlayActiviOpen=false
    }
}