package com.bitsTech.app.antithefttracker.model

data class Language(val name: String, val flagResource: Int,var isSelected:Boolean)
