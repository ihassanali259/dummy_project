package com.bitsTech.app.antithefttracker

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.bitsTech.app.antithefttracker.ui.activities.MainActivity
import com.bitsTech.solutions.app.antithefttracker.R

class Passcode : AppCompatActivity() {
    private var currentPin: String? = null
    private var newPin: String? = null
    private var step = 1

    private lateinit var sharedPreferences: SharedPreferences

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_passcode)
        val instructionTextView = findViewById<TextView>(R.id.instructionTextView)
        val currentPinEditText = findViewById<EditText>(R.id.passcodeEditText)
        val continueButton = findViewById<Button>(R.id.continueButton)


        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE)

        val hasSetPin = sharedPreferences.getBoolean("hasSetPin", false)
        val openedFromSplash = intent.getBooleanExtra("openedFromSplash", false)

        if (hasSetPin) {
            // User has already set a PIN, ask for the current PIN
            if (openedFromSplash){
                instructionTextView.text = "Enter Your PIN"
            }

            else {
                instructionTextView.text = "Enter Your Current PIN"
                step = 1
            }
        } else {
            // User hasn't set a PIN yet, ask to create a new PIN
            instructionTextView.text = "Create Your New PIN"
            step = 2
        }

        continueButton.setOnClickListener {
            when (step) {
                1 -> {
                    // Check if the entered current PIN is correct
                    val enteredCurrentPin = currentPinEditText.text.toString()
                    val storedPin = sharedPreferences.getString("pin", "")

                    if (openedFromSplash){
                        if (enteredCurrentPin == storedPin){
                            val intent = Intent(this, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                        else{
                            Toast.makeText(this, "Incorrect current PIN", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else {
                        if (enteredCurrentPin == storedPin) {
                            // Current PIN is correct, proceed to step 2
                            currentPinEditText.text.clear()
                            instructionTextView.text = "Enter Your New PIN"
                            step = 2
                        } else {
                            // Current PIN is incorrect, show an error message
                            Toast.makeText(this, "Incorrect current PIN", Toast.LENGTH_SHORT).show()
                        }

                    }
                }
                2 -> {
                    // Save the entered new PIN
                    newPin = currentPinEditText.text.toString()
                    currentPinEditText.text.clear()
                    instructionTextView.text = "Confirm Your New PIN"
                    step = 3
                }
                3 -> {
                    // Confirm the new PIN
                    val confirmPin = currentPinEditText.text.toString()
                    if (confirmPin == newPin) {
                        // New PIN confirmed, save it
                        val editor = sharedPreferences.edit()
                        editor.putString("pin", confirmPin)
                        editor.putBoolean("hasSetPin", true)
                        editor.apply()

                        // Proceed to the main activity
                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        // New PIN and confirmation don't match, show an error message
                        Toast.makeText(this, "New PINs do not match", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}