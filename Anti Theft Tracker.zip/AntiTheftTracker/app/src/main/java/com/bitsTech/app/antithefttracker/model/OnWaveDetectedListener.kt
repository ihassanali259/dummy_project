package com.bitsTech.app.antithefttracker.model

interface OnWaveDetectedListener {
    fun onWhistleDetected()
}