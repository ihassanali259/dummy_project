package com.bitsTech.app.antithefttracker.model

data class Languages(
    val imageResource: Int,
    val text: String,
    val languageCode: String,
    var isChecked: Boolean = false
)
